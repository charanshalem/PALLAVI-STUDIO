import { Camera, ShieldCheck } from 'lucide-react';

interface StudioEmblemProps {
  size?: 'sm' | 'md' | 'lg';
  showSecurity?: boolean;
  className?: string;
}

const sizes = {
  sm: { wrapper: 'w-12 h-12', text: 'text-lg', icon: 'w-3 h-3' },
  md: { wrapper: 'w-20 h-20', text: 'text-3xl', icon: 'w-4 h-4' },
  lg: { wrapper: 'w-28 h-28', text: 'text-5xl', icon: 'w-5 h-5' },
};

export default function StudioEmblem({ size = 'md', showSecurity = false, className = '' }: StudioEmblemProps) {
  const style = sizes[size];

  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <div className={`${style.wrapper} rounded-[38%] rotate-[-12deg] bg-gradient-to-br from-[#fff0a8] via-[#d99a28] to-[#7c4a08] p-[2px] shadow-[0_12px_35px_rgba(218,158,42,0.28)]`}>
        <div className="w-full h-full rounded-[38%] bg-[#17130d] flex items-center justify-center border border-[#f3c85c]/60">
          <span className={`${style.text} font-semibold tracking-[-0.18em] text-transparent bg-gradient-to-br from-[#fff0a8] via-[#e3aa36] to-[#8c570d] bg-clip-text translate-x-[-0.08em]`} style={{ fontFamily: 'Playfair Display, Georgia, serif' }}>
            SP
          </span>
        </div>
      </div>
      <Camera className={`absolute bottom-[-3px] right-[-5px] ${style.icon} text-[#f5c95d] drop-shadow-md`} />
      {showSecurity && (
        <span className="absolute -top-2 -right-2 rounded-full bg-[#dca438] p-1.5 text-[#17130d] shadow-lg" title="Protected admin portal">
          <ShieldCheck className="w-4 h-4" />
        </span>
      )}
    </div>
  );
}
