import { useEffect } from 'react';

export default function ScreenshotProtection() {
  useEffect(() => {
    const handleKeydown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (
        (e.ctrlKey || e.metaKey) &&
        (key === 's' || key === 'u' || key === 'p' || key === 'c')
      ) {
        if (key !== 'c' || !window.getSelection()?.toString()) {
          e.preventDefault();
        }
      }
      if (e.key === 'PrintScreen') {
        e.preventDefault();
        showWarning();
      }
      if (e.key === 'F12') {
        e.preventDefault();
      }
    };

    const handleCopy = (e: ClipboardEvent) => {
      e.preventDefault();
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    const handleBlur = () => {
      if (document.hidden) {
        showWarning();
      }
    };

    const showWarning = () => {
      const existing = document.getElementById('screenshot-warning');
      if (existing) return;
      const overlay = document.createElement('div');
      overlay.id = 'screenshot-warning';
      overlay.style.cssText = `
        position: fixed; inset: 0; z-index: 99999;
        background: rgba(17, 24, 39, 0.95);
        display: flex; align-items: center; justify-content: center;
        color: #f59e0b; font-size: 1.5rem; font-weight: 700;
        text-align: center; padding: 2rem;
        font-family: system-ui, -apple-system, sans-serif;
        backdrop-filter: blur(8px);
      `;
      overlay.innerHTML = `
        <div>
          <div style="font-size: 3rem; margin-bottom: 1rem;">&#9888;&#65039;</div>
          <div>Screenshots are not allowed</div>
          <div style="font-size: 1rem; color: #9ca3af; margin-top: 0.5rem; font-weight: 400;">
            Content on this site is protected by SRI PALLAVI STUDIO
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
      setTimeout(() => overlay.remove(), 2500);
    };

    document.addEventListener('keydown', handleKeydown);
    document.addEventListener('copy', handleCopy);
    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('visibilitychange', handleBlur);

    return () => {
      document.removeEventListener('keydown', handleKeydown);
      document.removeEventListener('copy', handleCopy);
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('visibilitychange', handleBlur);
    };
  }, []);

  return null;
}
