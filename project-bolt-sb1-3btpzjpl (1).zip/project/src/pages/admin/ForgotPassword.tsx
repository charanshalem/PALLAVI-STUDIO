import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { KeyRound, Mail, Loader2, ArrowLeft, CheckCircle } from 'lucide-react';
import StudioEmblem from '@/components/StudioEmblem';
import { useAuth } from '@/lib/auth';
import SEO from '@/components/SEO';

export default function ForgotPassword() {
  const { resetPassword } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('sripallavist174@gmail.com');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Please enter your email');
      return;
    }
    setLoading(true);
    setError(null);
    const { error: err } = await resetPassword(email);
    setLoading(false);
    if (err) {
      setError(err);
    } else {
      setSuccess(true);
    }
  };

  return (
    <>
      <SEO title="Forgot Password" description="Reset your admin password" />
      <div className="min-h-screen bg-gradient-to-b from-gray-950 via-gray-900 to-gray-950 flex items-center justify-center px-4 py-12">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        </div>

        <div className="relative w-full max-w-md">
          <Link to="/admin" className="inline-flex items-center gap-2 text-gray-400 hover:text-amber-400 transition-colors text-sm mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back to login
          </Link>

          <div className="bg-white/5 rounded-3xl border border-white/10 p-8 backdrop-blur-sm">
            <div className="text-center mb-8">
              <StudioEmblem size="lg" showSecurity className="mb-5" />
              <p className="text-amber-400 text-[10px] font-semibold uppercase tracking-[0.28em] mb-2">Owner-secured recovery</p>
              <h1 className="text-2xl font-bold text-white">Forgot Password</h1>
              <p className="text-gray-300 text-sm mt-2">U. Suresh Babu</p>
              <p className="text-gray-500 text-xs mt-1">SRI PALLAVI STUDIO Admin</p>
            </div>

            {success ? (
              <div className="text-center space-y-4">
                <CheckCircle className="w-16 h-16 text-amber-400 mx-auto" />
                <h3 className="text-xl font-semibold text-white">Check Your Email</h3>
                <p className="text-gray-400 text-sm">
                  We've sent a password reset link to <span className="text-amber-400">{email}</span>.
                  Click the link in the email to set a new password.
                </p>
                <button
                  onClick={() => navigate('/admin')}
                  className="w-full px-6 py-3 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold rounded-xl transition-all"
                >
                  Back to Login
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-gray-300 text-sm mb-2">Admin Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-600" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full pl-11 pr-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                      placeholder="sripallavist174@gmail.com"
                    />
                  </div>
                </div>
                <p className="text-gray-500 text-xs">
                  Enter your admin email address and we'll send you a secure link to reset your password.
                </p>
                {error && <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">{error}</div>}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 disabled:bg-amber-500/50 text-gray-900 font-semibold rounded-xl transition-all"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><KeyRound className="w-5 h-5" /> Send Reset Link</>}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
