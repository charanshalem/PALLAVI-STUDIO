import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, Mail, Loader2, ArrowLeft, KeyRound, ShieldCheck } from 'lucide-react';
import StudioEmblem from '@/components/StudioEmblem';
import { useAuth } from '@/lib/auth';
import SEO from '@/components/SEO';

export default function AdminLogin() {
  const { signInWithPassword, signInWithOtp, verifyOtp } = useAuth();
  const navigate = useNavigate();

  const [mode, setMode] = useState<'password' | 'otp'>('password');
  const [email, setEmail] = useState('sripallavist174@gmail.com');
  const [password, setPassword] = useState('');
  const [otpToken, setOtpToken] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please enter email and password');
      return;
    }
    setLoading(true);
    setError(null);
    const { error: err } = await signInWithPassword(email, password);
    setLoading(false);
    if (err) {
      setError(err);
    } else {
      navigate('/admin/dashboard');
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Please enter your email');
      return;
    }
    setLoading(true);
    setError(null);
    const { error: err } = await signInWithOtp(email);
    setLoading(false);
    if (err) {
      setError(err);
    } else {
      setOtpSent(true);
      setInfo('A login code has been sent to your email. Check your inbox (and spam folder).');
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !otpToken) {
      setError('Please enter the code');
      return;
    }
    setLoading(true);
    setError(null);
    const { error: err } = await verifyOtp(email, otpToken);
    setLoading(false);
    if (err) {
      setError(err);
    } else {
      navigate('/admin/dashboard');
    }
  };

  return (
    <>
      <SEO title="Admin Portal" description="Admin login for SRI PALLAVI STUDIO" />
      <div className="min-h-screen bg-gradient-to-b from-gray-950 via-gray-900 to-gray-950 flex items-center justify-center px-4 py-12">
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        </div>

        <div className="relative w-full max-w-md">
          <Link to="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-amber-400 transition-colors text-sm mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back to website
          </Link>

          <div className="bg-white/5 rounded-3xl border border-white/10 p-8 backdrop-blur-sm">
            {/* Logo */}
            <div className="text-center mb-8">
              <StudioEmblem size="lg" showSecurity className="mb-5" />
              <p className="text-amber-400 text-[10px] font-semibold uppercase tracking-[0.28em] mb-2">Owner-secured access</p>
              <h1 className="text-2xl font-bold text-white">Admin Portal</h1>
              <p className="text-gray-300 text-sm mt-2">U. Suresh Babu</p>
              <p className="text-gray-500 text-xs mt-1">SRI PALLAVI STUDIO</p>
            </div>

            {/* Mode Toggle */}
            <div className="flex gap-2 p-1 bg-gray-900/50 rounded-xl mb-6">
              <button
                onClick={() => { setMode('password'); setError(null); setInfo(null); }}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  mode === 'password' ? 'bg-amber-500 text-gray-900' : 'text-gray-400 hover:text-white'
                }`}
              >
                <Lock className="w-4 h-4" /> Password
              </button>
              <button
                onClick={() => { setMode('otp'); setError(null); setInfo(null); setOtpSent(false); }}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  mode === 'otp' ? 'bg-amber-500 text-gray-900' : 'text-gray-400 hover:text-white'
                }`}
              >
                <Mail className="w-4 h-4" /> Email Code
              </button>
            </div>

            {/* Password Mode */}
            {mode === 'password' && (
              <form onSubmit={handlePasswordLogin} className="space-y-4">
                <div>
                  <label className="block text-gray-300 text-sm mb-2">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                    placeholder="sripallavist174@gmail.com"
                  />
                </div>
                <div>
                  <label className="block text-gray-300 text-sm mb-2">Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                    placeholder="••••••••"
                  />
                </div>
                {error && <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">{error}</div>}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 disabled:bg-amber-500/50 text-gray-900 font-semibold rounded-xl transition-all"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><ShieldCheck className="w-5 h-5" /> Sign In</>}
                </button>
                <div className="text-center">
                  <Link to="/admin/forgot-password" className="inline-flex items-center gap-1 text-amber-400 text-sm hover:text-amber-300 transition-colors">
                    <KeyRound className="w-4 h-4" /> Forgot password?
                  </Link>
                </div>
              </form>
            )}

            {/* OTP Mode */}
            {mode === 'otp' && !otpSent && (
              <form onSubmit={handleSendOtp} className="space-y-4">
                <div>
                  <label className="block text-gray-300 text-sm mb-2">Admin Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                    placeholder="sripallavist174@gmail.com"
                  />
                </div>
                <p className="text-gray-500 text-xs">
                  A one-time login code will be sent to your email address.
                </p>
                {error && <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">{error}</div>}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 disabled:bg-amber-500/50 text-gray-900 font-semibold rounded-xl transition-all"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Mail className="w-5 h-5" /> Send Login Code</>}
                </button>
              </form>
            )}

            {/* OTP Verify */}
            {mode === 'otp' && otpSent && (
              <form onSubmit={handleVerifyOtp} className="space-y-4">
                {info && <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-sm">{info}</div>}
                <div>
                  <label className="block text-gray-300 text-sm mb-2">Enter Code</label>
                  <input
                    type="text"
                    value={otpToken}
                    onChange={(e) => setOtpToken(e.target.value)}
                    required
                    maxLength={6}
                    className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors text-center text-2xl tracking-[0.5em]"
                    placeholder="000000"
                  />
                </div>
                {error && <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">{error}</div>}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 disabled:bg-amber-500/50 text-gray-900 font-semibold rounded-xl transition-all"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldCheck className="w-5 h-5" />} Verify Code
                </button>
                <button
                  type="button"
                  onClick={() => { setOtpSent(false); setInfo(null); setError(null); }}
                  className="w-full text-center text-gray-400 text-sm hover:text-amber-400 transition-colors"
                >
                  Use a different email
                </button>
              </form>
            )}
          </div>

          <p className="text-center text-gray-600 text-xs mt-6">
            Authorized personnel only. All access is monitored and logged.
          </p>
        </div>
      </div>
    </>
  );
}
