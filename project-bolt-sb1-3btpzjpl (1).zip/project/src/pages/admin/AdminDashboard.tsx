import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Camera, LogOut, Upload, Trash2, Image as ImageIcon, Calendar, MessageSquare,
  Star, Loader2, X, Check, Edit3, Plus, Eye, Phone, Mail, Clock,
} from 'lucide-react';
import StudioEmblem from '@/components/StudioEmblem';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { GALLERY_CATEGORIES, type GalleryItem, type Booking, type Message, type Testimonial } from '@/types';
import SEO from '@/components/SEO';

type Tab = 'gallery' | 'upload' | 'bookings' | 'messages' | 'testimonials';

export default function AdminDashboard() {
  const { user, signOut, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [tab, setTab] = useState<Tab>('gallery');
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  // Upload form state
  const [uploadForm, setUploadForm] = useState({
    title: '', description: '', category: 'Wedding', media_type: 'photo', is_featured: false,
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  // Edit state
  const [editingItem, setEditingItem] = useState<GalleryItem | null>(null);

  // Testimonial form
  const [testForm, setTestForm] = useState({ name: '', rating: 5, content: '', event_type: '' });

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [g, b, m, t] = await Promise.all([
      supabase.from('gallery_items').select('*').order('created_at', { ascending: false }),
      supabase.from('bookings').select('*').order('created_at', { ascending: false }),
      supabase.from('messages').select('*').order('created_at', { ascending: false }),
      supabase.from('testimonials').select('*').order('created_at', { ascending: false }),
    ]);
    if (g.data) setGallery(g.data);
    if (b.data) setBookings(b.data);
    if (m.data) setMessages(m.data);
    if (t.data) setTestimonials(t.data);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/admin');
      return;
    }
    if (user) fetchData();
  }, [user, authLoading, navigate, fetchData]);

  const handleSignOut = async () => {
    await signOut();
    navigate('/admin');
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 100 * 1024 * 1024) {
        setUploadError('File size must be under 100MB');
        return;
      }
      setSelectedFile(file);
      setUploadError(null);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      setUploadError('Please select a file to upload');
      return;
    }
    if (!uploadForm.title) {
      setUploadError('Please enter a title');
      return;
    }

    setUploading(true);
    setUploadError(null);
    setUploadSuccess(false);
    setUploadProgress(0);

    const fileExt = selectedFile.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = `gallery/${fileName}`;

    setUploadProgress(20);

    const { error: uploadError } = await supabase.storage
      .from('studio-media')
      .upload(filePath, selectedFile, { cacheControl: '3600' });

    if (uploadError) {
      setUploadError(`Upload failed: ${uploadError.message}`);
      setUploading(false);
      return;
    }

    setUploadProgress(60);

    const { data: urlData } = supabase.storage.from('studio-media').getPublicUrl(filePath);
    const mediaUrl = urlData.publicUrl;

    setUploadProgress(80);

    const { error: dbError } = await supabase.from('gallery_items').insert({
      title: uploadForm.title,
      description: uploadForm.description || null,
      category: uploadForm.category,
      media_type: uploadForm.media_type,
      media_url: mediaUrl,
      is_featured: uploadForm.is_featured,
      sort_order: 0,
    });

    setUploadProgress(100);
    setUploading(false);

    if (dbError) {
      setUploadError(`Database error: ${dbError.message}`);
      return;
    }

    setUploadSuccess(true);
    setSelectedFile(null);
    setUploadForm({ title: '', description: '', category: 'Wedding', media_type: 'photo', is_featured: false });
    setTimeout(() => setUploadSuccess(false), 3000);
    fetchData();

    // Reset file input
    const fileInput = document.getElementById('file-upload') as HTMLInputElement;
    if (fileInput) fileInput.value = '';
  };

  const handleDeleteGallery = async (item: GalleryItem) => {
    if (!confirm(`Delete "${item.title}"? This cannot be undone.`)) return;

    // Extract path from URL
    const urlParts = item.media_url.split('/studio-media/');
    if (urlParts.length > 1) {
      await supabase.storage.from('studio-media').remove([urlParts[1]]);
    }

    await supabase.from('gallery_items').delete().eq('id', item.id);
    setGallery(gallery.filter((g) => g.id !== item.id));
  };

  const handleUpdateGallery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;
    await supabase.from('gallery_items').update({
      title: editingItem.title,
      description: editingItem.description,
      category: editingItem.category,
      is_featured: editingItem.is_featured,
    }).eq('id', editingItem.id);
    setEditingItem(null);
    fetchData();
  };

  const handleUpdateBookingStatus = async (id: string, status: string) => {
    await supabase.from('bookings').update({ status }).eq('id', id);
    setBookings(bookings.map((b) => (b.id === id ? { ...b, status: status as Booking['status'] } : b)));
  };

  const handleDeleteBooking = async (id: string) => {
    if (!confirm('Delete this booking?')) return;
    await supabase.from('bookings').delete().eq('id', id);
    setBookings(bookings.filter((b) => b.id !== id));
  };

  const handleDeleteMessage = async (id: string) => {
    if (!confirm('Delete this message?')) return;
    await supabase.from('messages').delete().eq('id', id);
    setMessages(messages.filter((m) => m.id !== id));
  };

  const handleAddTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testForm.name || !testForm.content) return;
    await supabase.from('testimonials').insert({
      name: testForm.name,
      rating: testForm.rating,
      content: testForm.content,
      event_type: testForm.event_type || null,
    });
    setTestForm({ name: '', rating: 5, content: '', event_type: '' });
    fetchData();
  };

  const handleDeleteTestimonial = async (id: string) => {
    if (!confirm('Delete this testimonial?')) return;
    await supabase.from('testimonials').delete().eq('id', id);
    setTestimonials(testimonials.filter((t) => t.id !== id));
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
      </div>
    );
  }

  if (!user) return null;

  const tabs: { id: Tab; label: string; icon: typeof Camera; count?: number }[] = [
    { id: 'gallery', label: 'Gallery', icon: ImageIcon, count: gallery.length },
    { id: 'upload', label: 'Upload', icon: Upload },
    { id: 'bookings', label: 'Bookings', icon: Calendar, count: bookings.filter(b => b.status === 'pending').length },
    { id: 'messages', label: 'Messages', icon: MessageSquare, count: messages.length },
    { id: 'testimonials', label: 'Testimonials', icon: Star, count: testimonials.length },
  ];

  return (
    <>
      <SEO title="Admin Dashboard" description="SRI PALLAVI STUDIO admin dashboard" />
      <div className="min-h-screen bg-gray-950">
        {/* Top Bar */}
        <header className="bg-gray-900/80 backdrop-blur-md border-b border-white/10 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-3">
                <StudioEmblem size="sm" showSecurity />
                <div className="leading-none">
                  <span className="text-white font-bold text-sm">SRI PALLAVI STUDIO</span>
                  <span className="block text-amber-400 text-[10px] tracking-widest">OWNER DASHBOARD</span>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="hidden sm:block text-right leading-tight">
                  <span className="text-gray-200 text-sm block">U. Suresh Babu</span>
                  <span className="text-gray-500 text-xs">{user.email}</span>
                </div>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-sm font-medium transition-all"
                >
                  <LogOut className="w-4 h-4" /> Sign Out
                </button>
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                  tab === t.id
                    ? 'bg-amber-500 text-gray-900'
                    : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
                }`}
              >
                <t.icon className="w-4 h-4" />
                {t.label}
                {t.count !== undefined && t.count > 0 && (
                  <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                    tab === t.id ? 'bg-gray-900/20 text-gray-900' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {t.count}
                  </span>
                )}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="flex justify-center py-20">
              <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
            </div>
          ) : (
            <>
              {/* Gallery Tab */}
              {tab === 'gallery' && (
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold text-white">Gallery Management ({gallery.length})</h2>
                    <button
                      onClick={() => setTab('upload')}
                      className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-gray-900 text-sm font-medium rounded-lg transition-all"
                    >
                      <Plus className="w-4 h-4" /> Add New
                    </button>
                  </div>
                  {gallery.length === 0 ? (
                    <div className="text-center py-20 text-gray-500">
                      <ImageIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No photos yet. Upload your first one!</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                      {gallery.map((item) => (
                        <div key={item.id} className="group relative rounded-xl overflow-hidden bg-white/5 border border-white/10">
                          <img
                            src={item.media_url}
                            alt={item.title}
                            className="w-full aspect-square object-cover"
                            loading="lazy"
                          />
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3">
                            <div className="flex justify-end gap-1">
                              <button
                                onClick={() => setEditingItem(item)}
                                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-amber-500 flex items-center justify-center transition-all"
                              >
                                <Edit3 className="w-4 h-4 text-white" />
                              </button>
                              <button
                                onClick={() => handleDeleteGallery(item)}
                                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-red-500 flex items-center justify-center transition-all"
                              >
                                <Trash2 className="w-4 h-4 text-white" />
                              </button>
                            </div>
                            <div>
                              <p className="text-white text-xs font-medium truncate">{item.title}</p>
                              <p className="text-amber-400 text-[10px]">{item.category}</p>
                              {item.is_featured && <span className="inline-block text-[10px] text-amber-300 mt-1">★ Featured</span>}
                            </div>
                          </div>
                          {item.is_featured && (
                            <div className="absolute top-2 left-2 w-6 h-6 rounded-full bg-amber-500 flex items-center justify-center">
                              <Star className="w-3.5 h-3.5 text-gray-900 fill-gray-900" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Upload Tab */}
              {tab === 'upload' && (
                <div className="max-w-2xl">
                  <h2 className="text-xl font-semibold text-white mb-6">Upload New Photo/Video</h2>
                  <form onSubmit={handleUpload} className="space-y-5">
                    {/* File Drop Zone */}
                    <div>
                      <label className="block text-gray-300 text-sm mb-2">Select File *</label>
                      <label
                        htmlFor="file-upload"
                        className="flex flex-col items-center justify-center border-2 border-dashed border-white/15 rounded-2xl p-8 cursor-pointer hover:border-amber-500/50 transition-all bg-gray-900/30"
                      >
                        {selectedFile ? (
                          <div className="text-center">
                            <Check className="w-10 h-10 text-amber-400 mx-auto mb-2" />
                            <p className="text-white text-sm font-medium">{selectedFile.name}</p>
                            <p className="text-gray-500 text-xs mt-1">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                          </div>
                        ) : (
                          <div className="text-center">
                            <Upload className="w-10 h-10 text-gray-600 mx-auto mb-2" />
                            <p className="text-gray-400 text-sm">Click to select a file</p>
                            <p className="text-gray-600 text-xs mt-1">Photos and videos up to 100MB</p>
                          </div>
                        )}
                        <input id="file-upload" type="file" accept="image/*,video/*" onChange={handleFileSelect} className="hidden" />
                      </label>
                    </div>

                    <div>
                      <label className="block text-gray-300 text-sm mb-2">Title *</label>
                      <input
                        type="text"
                        value={uploadForm.title}
                        onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
                        required
                        className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                        placeholder="e.g. Beautiful Wedding Ceremony"
                      />
                    </div>

                    <div>
                      <label className="block text-gray-300 text-sm mb-2">Description</label>
                      <textarea
                        value={uploadForm.description}
                        onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                        rows={3}
                        className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors resize-none"
                        placeholder="Optional description..."
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-300 text-sm mb-2">Category</label>
                        <select
                          value={uploadForm.category}
                          onChange={(e) => setUploadForm({ ...uploadForm, category: e.target.value })}
                          className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white focus:border-amber-500/50 focus:outline-none transition-colors"
                        >
                          {GALLERY_CATEGORIES.filter((c) => c !== 'All').map((cat) => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-gray-300 text-sm mb-2">Media Type</label>
                        <select
                          value={uploadForm.media_type}
                          onChange={(e) => setUploadForm({ ...uploadForm, media_type: e.target.value as 'photo' | 'video' })}
                          className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white focus:border-amber-500/50 focus:outline-none transition-colors"
                        >
                          <option value="photo">Photo</option>
                          <option value="video">Video</option>
                        </select>
                      </div>
                    </div>

                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={uploadForm.is_featured}
                        onChange={(e) => setUploadForm({ ...uploadForm, is_featured: e.target.checked })}
                        className="w-5 h-5 rounded accent-amber-500"
                      />
                      <span className="text-gray-300 text-sm">Show on homepage (Featured)</span>
                    </label>

                    {uploading && (
                      <div className="w-full bg-gray-900 rounded-full h-2 overflow-hidden">
                        <div className="h-full bg-amber-500 transition-all duration-300" style={{ width: `${uploadProgress}%` }} />
                      </div>
                    )}

                    {uploadError && <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">{uploadError}</div>}
                    {uploadSuccess && <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-sm flex items-center gap-2"><Check className="w-4 h-4" /> Upload successful!</div>}

                    <button
                      type="submit"
                      disabled={uploading}
                      className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 disabled:bg-amber-500/50 text-gray-900 font-semibold rounded-xl transition-all"
                    >
                      {uploading ? <><Loader2 className="w-5 h-5 animate-spin" /> Uploading...</> : <><Upload className="w-5 h-5" /> Upload</>}
                    </button>
                  </form>
                </div>
              )}

              {/* Bookings Tab */}
              {tab === 'bookings' && (
                <div>
                  <h2 className="text-xl font-semibold text-white mb-6">Booking Requests ({bookings.length})</h2>
                  {bookings.length === 0 ? (
                    <div className="text-center py-20 text-gray-500">
                      <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No booking requests yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {bookings.map((booking) => (
                        <div key={booking.id} className="p-5 bg-white/5 rounded-2xl border border-white/10">
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h3 className="text-white font-semibold">{booking.name}</h3>
                                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                                  booking.status === 'pending' ? 'bg-amber-500/20 text-amber-400' :
                                  booking.status === 'confirmed' ? 'bg-green-500/20 text-green-400' :
                                  booking.status === 'completed' ? 'bg-blue-500/20 text-blue-400' :
                                  'bg-red-500/20 text-red-400'
                                }`}>{booking.status}</span>
                              </div>
                              <p className="text-amber-400 text-sm mb-3">{booking.event_type}</p>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-gray-400">
                                <span className="flex items-center gap-2"><Mail className="w-4 h-4" /> {booking.email}</span>
                                <span className="flex items-center gap-2"><Phone className="w-4 h-4" /> {booking.phone}</span>
                                {booking.event_date && <span className="flex items-center gap-2"><Calendar className="w-4 h-4" /> {booking.event_date}</span>}
                                <span className="flex items-center gap-2"><Clock className="w-4 h-4" /> {new Date(booking.created_at).toLocaleDateString()}</span>
                              </div>
                              {booking.message && <p className="text-gray-400 text-sm mt-3 italic">"{booking.message}"</p>}
                            </div>
                            <div className="flex flex-col gap-2">
                              <select
                                value={booking.status}
                                onChange={(e) => handleUpdateBookingStatus(booking.id, e.target.value)}
                                className="px-3 py-2 bg-gray-900/50 border border-white/10 rounded-lg text-white text-sm focus:border-amber-500/50 focus:outline-none"
                              >
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                              </select>
                              <button
                                onClick={() => handleDeleteBooking(booking.id)}
                                className="flex items-center justify-center gap-1 px-3 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-sm transition-all"
                              >
                                <Trash2 className="w-4 h-4" /> Delete
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Messages Tab */}
              {tab === 'messages' && (
                <div>
                  <h2 className="text-xl font-semibold text-white mb-6">Messages ({messages.length})</h2>
                  {messages.length === 0 ? (
                    <div className="text-center py-20 text-gray-500">
                      <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No messages yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {messages.map((msg) => (
                        <div key={msg.id} className="p-5 bg-white/5 rounded-2xl border border-white/10">
                          <div className="flex justify-between items-start gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h3 className="text-white font-semibold">{msg.name}</h3>
                                <span className="text-gray-600 text-xs">{new Date(msg.created_at).toLocaleDateString()}</span>
                              </div>
                              {msg.subject && <p className="text-amber-400 text-sm mb-2">{msg.subject}</p>}
                              <div className="flex flex-wrap gap-3 text-xs text-gray-500 mb-2">
                                <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {msg.email}</span>
                                {msg.phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {msg.phone}</span>}
                              </div>
                              <p className="text-gray-300 text-sm">{msg.message}</p>
                            </div>
                            <button
                              onClick={() => handleDeleteMessage(msg.id)}
                              className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-all"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Testimonials Tab */}
              {tab === 'testimonials' && (
                <div>
                  <h2 className="text-xl font-semibold text-white mb-6">Testimonials ({testimonials.length})</h2>

                  {/* Add Testimonial Form */}
                  <form onSubmit={handleAddTestimonial} className="p-5 bg-white/5 rounded-2xl border border-white/10 mb-6">
                    <h3 className="text-white font-medium mb-4 flex items-center gap-2"><Plus className="w-5 h-5 text-amber-400" /> Add Testimonial</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                      <input
                        type="text"
                        placeholder="Customer name"
                        value={testForm.name}
                        onChange={(e) => setTestForm({ ...testForm, name: e.target.value })}
                        required
                        className="px-4 py-2.5 bg-gray-900/50 border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-amber-500/50 focus:outline-none"
                      />
                      <input
                        type="text"
                        placeholder="Event type (optional)"
                        value={testForm.event_type}
                        onChange={(e) => setTestForm({ ...testForm, event_type: e.target.value })}
                        className="px-4 py-2.5 bg-gray-900/50 border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-amber-500/50 focus:outline-none"
                      />
                    </div>
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-gray-400 text-sm">Rating:</span>
                      {[1, 2, 3, 4, 5].map((r) => (
                        <button
                          key={r}
                          type="button"
                          onClick={() => setTestForm({ ...testForm, rating: r })}
                        >
                          <Star className={`w-5 h-5 ${r <= testForm.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-700'}`} />
                        </button>
                      ))}
                    </div>
                    <textarea
                      placeholder="Review content"
                      value={testForm.content}
                      onChange={(e) => setTestForm({ ...testForm, content: e.target.value })}
                      required
                      rows={3}
                      className="w-full px-4 py-2.5 bg-gray-900/50 border border-white/10 rounded-xl text-white text-sm placeholder-gray-600 focus:border-amber-500/50 focus:outline-none resize-none mb-3"
                    />
                    <button type="submit" className="flex items-center gap-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-gray-900 text-sm font-medium rounded-xl transition-all">
                      <Plus className="w-4 h-4" /> Add Testimonial
                    </button>
                  </form>

                  {/* Testimonial List */}
                  <div className="space-y-3">
                    {testimonials.map((t) => (
                      <div key={t.id} className="p-4 bg-white/5 rounded-xl border border-white/10 flex justify-between items-start gap-4">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="text-white font-medium text-sm">{t.name}</h4>
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} className={`w-3.5 h-3.5 ${i < t.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-700'}`} />
                              ))}
                            </div>
                          </div>
                          {t.event_type && <p className="text-amber-400 text-xs mb-1">{t.event_type}</p>}
                          <p className="text-gray-400 text-sm">{t.content}</p>
                        </div>
                        <button
                          onClick={() => handleDeleteTestimonial(t.id)}
                          className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-all flex-shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Edit Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4" onClick={() => setEditingItem(null)}>
          <div className="bg-gray-900 rounded-2xl border border-white/10 p-6 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-white font-semibold text-lg">Edit Gallery Item</h3>
              <button onClick={() => setEditingItem(null)} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <img src={editingItem.media_url} alt={editingItem.title} className="w-full h-40 object-cover rounded-xl mb-4" />
            <form onSubmit={handleUpdateGallery} className="space-y-4">
              <div>
                <label className="block text-gray-300 text-sm mb-2">Title</label>
                <input
                  type="text"
                  value={editingItem.title}
                  onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                  className="w-full px-4 py-2.5 bg-gray-800 border border-white/10 rounded-xl text-white text-sm focus:border-amber-500/50 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm mb-2">Description</label>
                <textarea
                  value={editingItem.description ?? ''}
                  onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2.5 bg-gray-800 border border-white/10 rounded-xl text-white text-sm focus:border-amber-500/50 focus:outline-none resize-none"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm mb-2">Category</label>
                <select
                  value={editingItem.category}
                  onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                  className="w-full px-4 py-2.5 bg-gray-800 border border-white/10 rounded-xl text-white text-sm focus:border-amber-500/50 focus:outline-none"
                >
                  {GALLERY_CATEGORIES.filter((c) => c !== 'All').map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={editingItem.is_featured}
                  onChange={(e) => setEditingItem({ ...editingItem, is_featured: e.target.checked })}
                  className="w-5 h-5 rounded accent-amber-500"
                />
                <span className="text-gray-300 text-sm">Featured on homepage</span>
              </label>
              <button type="submit" className="w-full px-6 py-3 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold rounded-xl transition-all">
                Save Changes
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
