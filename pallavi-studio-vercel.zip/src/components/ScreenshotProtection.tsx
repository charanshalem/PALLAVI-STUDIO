import { useEffect, useRef, useState } from 'react';

// Browsers cannot prevent operating-system screenshots or screen recordings.
export default function ScreenshotProtection() {
  const [warning, setWarning] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout>>();
  useEffect(() => {
    const showWarning = () => {
      setWarning(true);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setWarning(false), 3500);
    };
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'PrintScreen') showWarning();
    };
    const handleMedia = (event: MouseEvent | DragEvent) => {
      if (event.target instanceof HTMLElement && event.target.closest('img, video')) {
        event.preventDefault();
        showWarning();
      }
    };
    document.addEventListener('keyup', handleKey);
    document.addEventListener('contextmenu', handleMedia);
    document.addEventListener('dragstart', handleMedia);
    return () => {
      clearTimeout(timer.current);
      document.removeEventListener('keyup', handleKey);
      document.removeEventListener('contextmenu', handleMedia);
      document.removeEventListener('dragstart', handleMedia);
    };
  }, []);
  return warning ? (
    <div role="status" className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[99999] w-[90%] max-w-md rounded-xl border border-amber-400/40 bg-gray-950 p-5 text-center text-white shadow-xl">
      <p className="font-semibold text-amber-400">Please do not screenshot or copy our work.</p>
      <p className="mt-2 text-sm text-gray-300">Images belong to Sri Pallavi Studio. Contact us for permission to use them.</p>
      <button type="button" onClick={() => setWarning(false)} className="mt-3 rounded border border-gray-500 px-3 py-1">Dismiss</button>
    </div>
  ) : null;
}
