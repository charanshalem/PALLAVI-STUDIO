import { ShieldCheck } from 'lucide-react';

interface StudioEmblemProps {
  size?: 'sm' | 'md' | 'lg';
  showSecurity?: boolean;
  className?: string;
}

const sizes = {
  sm: { wrapper: 'w-12 h-12', text: 'text-lg', icon: 'w-3 h-3' },
  md: { wrapper: 'w-20 h-20', text: 'text-3xl', icon: 'w-4 h-4' },
  lg: { wrapper: 'w-28 h-28', text: 'text-5xl', icon: 'w-5 h-5' },
};

export default function StudioEmblem({ size = 'md', showSecurity = false, className = '' }: StudioEmblemProps) {
  const style = sizes[size];

  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <img
        src="/studio-emblem.png"
        alt="Sri Pallavi Studio — gold SP emblem"
        width={431}
        height={438}
        className={`${style.wrapper} object-contain rounded-lg shadow-[0_8px_24px_rgba(218,158,42,0.18)]`}
        draggable={false}
      />
      {showSecurity && (
        <span className="absolute -top-2 -right-2 rounded-full bg-[#dca438] p-1.5 text-[#17130d] shadow-lg" title="Protected admin portal">
          <ShieldCheck className="w-4 h-4" />
        </span>
      )}
    </div>
  );
}
