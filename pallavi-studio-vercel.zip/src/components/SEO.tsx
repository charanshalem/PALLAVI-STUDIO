import { useEffect } from 'react';
import { STUDIO_INFO } from '@/lib/supabase';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  type?: string;
}

export default function SEO({
  title,
  description = 'SRI PALLAVI STUDIO - Professional photography and videography services in Pithapuram. Wedding photography, portraits, events, and more. Capturing your precious moments with artistry.',
  keywords = 'photography studio Pithapuram, wedding photography, pre-wedding shoot, portrait photography, videography, event photography, SRI PALLAVI STUDIO, Andhra Pradesh photographer',
  image = 'https://images.pexels.com/photos/11234300/pexels-photo-11234300.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  type = 'website',
}: SEOProps) {
  useEffect(() => {
    const fullTitle = title ? `${title} | ${STUDIO_INFO.name}` : `${STUDIO_INFO.name} - ${STUDIO_INFO.tagline}`;
    document.title = fullTitle;

    const setMeta = (selector: string, attr: string, content: string) => {
      let el = document.querySelector(selector) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement('meta');
        const [, name] = selector.match(/\[(?:name|property)="(.+?)"\]/) ?? [];
        if (selector.includes('property')) el.setAttribute('property', name);
        else el.setAttribute('name', name);
        document.head.appendChild(el);
      }
      el.setAttribute(attr, content);
    };

    setMeta('meta[name="description"]', 'content', description);
    setMeta('meta[name="keywords"]', 'content', keywords);
    setMeta('meta[property="og:title"]', 'content', fullTitle);
    setMeta('meta[property="og:description"]', 'content', description);
    setMeta('meta[property="og:type"]', 'content', type);
    setMeta('meta[property="og:image"]', 'content', image);
    setMeta('meta[name="twitter:card"]', 'content', 'summary_large_image');
    setMeta('meta[name="twitter:title"]', 'content', fullTitle);
    setMeta('meta[name="twitter:description"]', 'content', description);
    setMeta('meta[name="twitter:image"]', 'content', image);

    let structuredData = document.getElementById('structured-data');
    if (!structuredData) {
      structuredData = document.createElement('script');
      structuredData.id = 'structured-data';
      structuredData.setAttribute('type', 'application/ld+json');
      document.head.appendChild(structuredData);
    }
    structuredData.textContent = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'PhotographyBusiness',
      name: STUDIO_INFO.name,
      description: description,
      address: {
        '@type': 'PostalAddress',
        streetAddress: 'Near Old Police Station',
        addressLocality: 'Pithapuram',
        addressRegion: 'Andhra Pradesh',
        addressCountry: 'IN',
      },
      telephone: STUDIO_INFO.phone,
      email: STUDIO_INFO.email,
      url: window.location.origin,
      hasMap: STUDIO_INFO.mapsUrl,
      sameAs: Object.values(STUDIO_INFO.socials).filter((s) => s !== '#'),
    });
  }, [title, description, keywords, image, type]);

  return null;
}
