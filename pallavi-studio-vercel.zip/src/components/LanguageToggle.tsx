import { useLanguage, type Language } from '@/lib/language';
import { Globe } from 'lucide-react';

export default function LanguageToggle({ className = '' }: { className?: string }) {
  const { lang, setLang } = useLanguage();

  const toggle = () => {
    const next: Language = lang === 'en' ? 'te' : 'en';
    setLang(next);
  };

  return (
    <button
      onClick={toggle}
      className={`flex items-center gap-1.5 text-sm font-medium text-gray-200 hover:text-amber-300 transition-colors ${className}`}
      aria-label="Toggle language"
    >
      <Globe className="w-4 h-4" />
      <span>{lang === 'en' ? 'EN' : 'TE'}</span>
    </button>
  );
}
