import { Link } from 'react-router-dom';
import {
  Instagram, Facebook, Youtube, MessageCircle, MapPin, Phone, Mail,
} from 'lucide-react';
import { STUDIO_INFO } from '@/lib/supabase';
import StudioEmblem from '@/components/StudioEmblem';

export default function Footer() {
  return (
    <footer className="bg-gray-950 text-gray-400 pt-16 pb-8 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <StudioEmblem size="sm" />
              <div className="flex flex-col leading-none">
                <span
                  className="text-white font-bold text-base tracking-wide"
                  style={{ fontFamily: 'Playfair Display, serif' }}
                >
                  SRI PALLAVI
                </span>
                <span className="text-amber-400 text-xs tracking-[0.3em]">STUDIO</span>
              </div>
            </div>
            <p className="text-sm leading-relaxed mb-4">
              {STUDIO_INFO.tagline}. Professional photography and videography services in Pithapuram, Andhra Pradesh.
            </p>
            <div className="flex gap-3">
              <a
                href={STUDIO_INFO.socials.instagram}
                className="w-10 h-10 rounded-full bg-white/5 hover:bg-amber-500 flex items-center justify-center transition-all hover:scale-110 group"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5 text-gray-400 group-hover:text-gray-900" />
              </a>
              <a
                href={STUDIO_INFO.socials.facebook}
                className="w-10 h-10 rounded-full bg-white/5 hover:bg-amber-500 flex items-center justify-center transition-all hover:scale-110 group"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5 text-gray-400 group-hover:text-gray-900" />
              </a>
              <a
                href={STUDIO_INFO.socials.youtube}
                className="w-10 h-10 rounded-full bg-white/5 hover:bg-amber-500 flex items-center justify-center transition-all hover:scale-110 group"
                aria-label="YouTube"
              >
                <Youtube className="w-5 h-5 text-gray-400 group-hover:text-gray-900" />
              </a>
              <a
                href={`https://wa.me/${STUDIO_INFO.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/5 hover:bg-amber-500 flex items-center justify-center transition-all hover:scale-110 group"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-5 h-5 text-gray-400 group-hover:text-gray-900" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/" className="hover:text-amber-400 transition-colors">Home</Link></li>
              <li><Link to="/about" className="hover:text-amber-400 transition-colors">About Us</Link></li>
              <li><Link to="/gallery" className="hover:text-amber-400 transition-colors">Gallery</Link></li>
              <li><Link to="/videos" className="hover:text-amber-400 transition-colors">Cinematic Films</Link></li>
              <li><Link to="/reviews" className="hover:text-amber-400 transition-colors">Customer Reviews</Link></li>
              <li><Link to="/faq" className="hover:text-amber-400 transition-colors">FAQ</Link></li>
              <li><Link to="/booking" className="hover:text-amber-400 transition-colors">Book a Session</Link></li>
              <li><Link to="/contact" className="hover:text-amber-400 transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-4">Our Services</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/services" className="hover:text-amber-400 transition-colors">Wedding Photography</Link></li>
              <li><Link to="/services" className="hover:text-amber-400 transition-colors">Pre-Wedding Shoots</Link></li>
              <li><Link to="/services" className="hover:text-amber-400 transition-colors">Portrait Sessions</Link></li>
              <li><Link to="/services" className="hover:text-amber-400 transition-colors">Kids Photography</Link></li>
              <li><Link to="/services" className="hover:text-amber-400 transition-colors">Event Coverage</Link></li>
              <li><Link to="/services" className="hover:text-amber-400 transition-colors">Cinematic Videography</Link></li>
              <li><Link to="/services" className="hover:text-amber-400 transition-colors">Photo Restoration</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-4">Get in Touch</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                <a
                  href={STUDIO_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-amber-400 transition-colors"
                >
                  {STUDIO_INFO.address}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <a href={`tel:${STUDIO_INFO.phone}`} className="hover:text-amber-400 transition-colors">
                  {STUDIO_INFO.phone}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <a
                  href={`mailto:${STUDIO_INFO.email}`}
                  className="hover:text-amber-400 transition-colors break-all"
                >
                  {STUDIO_INFO.email}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <p>
            &copy; {new Date().getFullYear()} {STUDIO_INFO.name}. All rights reserved.
          </p>
          <p className="text-gray-600">Owner: {STUDIO_INFO.owner} · Every Moment Deserves to Be Timeless</p>
        </div>
      </div>
    </footer>
  );
}
