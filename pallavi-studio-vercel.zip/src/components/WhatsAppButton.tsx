import { MessageCircle } from 'lucide-react';
import { STUDIO_INFO } from '@/lib/supabase';

export default function WhatsAppButton() {
  const handleClick = () => {
    const message = encodeURIComponent(
      `Hello ${STUDIO_INFO.name}! I'd like to know more about your photography services.`
    );
    window.open(`https://wa.me/${STUDIO_INFO.whatsapp}?text=${message}`, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      aria-label="Chat on WhatsApp"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-green-500 hover:bg-green-400 text-white shadow-lg shadow-green-500/30 flex items-center justify-center transition-all duration-300 hover:scale-110 animate-pulse-glow group"
    >
      <MessageCircle className="w-7 h-7" />
      <span className="absolute right-full mr-3 whitespace-nowrap bg-gray-900 text-white text-sm px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        Chat with us
      </span>
    </button>
  );
}
