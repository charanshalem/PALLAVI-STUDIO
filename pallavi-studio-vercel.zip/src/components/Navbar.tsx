import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useLanguage } from '@/lib/language';
import LanguageToggle from '@/components/LanguageToggle';
import StudioEmblem from '@/components/StudioEmblem';

const mainLinks = [
  { labelKey: 'nav_home', path: '/' },
  { labelKey: 'nav_about', path: '/about' },
  { labelKey: 'nav_services', path: '/services' },
  { labelKey: 'nav_gallery', path: '/gallery' },
  { labelKey: 'nav_videos', path: '/videos' },
  { labelKey: 'nav_reviews', path: '/reviews' },
  { labelKey: 'nav_faq', path: '/faq' },
  { labelKey: 'nav_contact', path: '/contact' },
];

export default function Navbar() {
  const { t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) =>
    path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-gray-950/95 backdrop-blur-md shadow-lg shadow-black/30'
          : 'bg-gradient-to-b from-black/70 to-transparent'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group flex-shrink-0">
            <StudioEmblem size="sm" />
            <div className="flex flex-col leading-none">
              <span
                className="text-white font-bold text-sm sm:text-lg tracking-wide"
                style={{ fontFamily: 'Playfair Display, serif' }}
              >
                SRI PALLAVI
              </span>
              <span className="text-amber-400 text-[10px] sm:text-xs tracking-[0.3em] font-medium">
                STUDIO
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-0.5">
            {mainLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`relative px-3 py-2 text-sm font-medium transition-colors duration-300 whitespace-nowrap ${
                  isActive(link.path) ? 'text-amber-400' : 'text-gray-200 hover:text-amber-300'
                }`}
              >
                {t(link.labelKey)}
                <span
                  className={`absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 bg-amber-400 transition-all duration-300 ${
                    isActive(link.path) ? 'w-3/4' : 'w-0'
                  }`}
                />
              </Link>
            ))}
            <LanguageToggle className="ml-2" />
            <button
              onClick={() => navigate('/booking')}
              className="ml-3 px-5 py-2 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold text-sm rounded-full transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/30 hover:scale-105"
            >
              {t('nav_book')}
            </button>
          </div>

          {/* Mobile toggle */}
          <div className="lg:hidden flex items-center gap-2">
            <LanguageToggle />
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-white p-2"
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        <div
          className={`lg:hidden overflow-hidden transition-all duration-400 ${
            isOpen ? 'max-h-[600px] pb-4' : 'max-h-0'
          }`}
        >
          <div className="flex flex-col gap-1">
            {mainLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  isActive(link.path)
                    ? 'text-amber-400 bg-amber-500/10'
                    : 'text-gray-200 hover:text-amber-300 hover:bg-white/5'
                }`}
              >
                {t(link.labelKey)}
              </Link>
            ))}
            <button
              onClick={() => {
                setIsOpen(false);
                navigate('/booking');
              }}
              className="mt-2 mx-4 py-3 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold text-sm rounded-full text-center transition-all"
            >
              {t('nav_book')}
            </button>
            <Link
              to="/admin"
              className="mx-4 py-2 text-center text-xs text-gray-400 hover:text-amber-300 transition-colors"
            >
              {t('nav_admin')}
            </Link>
          </div>
        </div>
      </nav>
    </header>
  );
}
