import { useState } from 'react';
import { X, Sparkles } from 'lucide-react';

export default function AnnouncementBanner() {
  const [visible, setVisible] = useState(true);

  if (!visible) return null;

  return (
    <div className="relative bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 text-gray-900 text-center text-sm py-2 px-4 font-medium z-50">
      <div className="flex items-center justify-center gap-2 pr-8">
        <Sparkles className="w-4 h-4 flex-shrink-0" />
        <span className="truncate">
          Wedding Season Special — Book your wedding package now and get a complimentary pre-wedding shoot!
        </span>
      </div>
      <button
        onClick={() => setVisible(false)}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-900/70 hover:text-gray-900 transition-colors"
        aria-label="Dismiss announcement"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
