export interface GalleryItem {
  id: string;
  title: string;
  description: string | null;
  category: string;
  media_type: 'photo' | 'video';
  media_url: string;
  thumbnail_url: string | null;
  is_featured: boolean;
  sort_order: number;
  created_at: string;
}

export interface Booking {
  id: string;
  name: string;
  email: string;
  phone: string;
  event_type: string;
  event_date: string | null;
  message: string | null;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  created_at: string;
}

export interface Message {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  subject: string | null;
  message: string;
  created_at: string;
}

export interface Testimonial {
  id: string;
  name: string;
  rating: number;
  content: string;
  event_type: string | null;
  created_at: string;
}

export const GALLERY_CATEGORIES = [
  'All',
  'Wedding',
  'Pre-Wedding',
  'Portrait',
  'Kids',
  'Events',
  'Maternity',
  'General',
];

export const SERVICE_CATEGORIES = [
  { id: 'wedding', name: 'Wedding Photography', icon: 'Heart' },
  { id: 'pre-wedding', name: 'Pre-Wedding Shoot', icon: 'Camera' },
  { id: 'portrait', name: 'Portrait Sessions', icon: 'User' },
  { id: 'kids', name: 'Kids Photography', icon: 'Baby' },
  { id: 'events', name: 'Event Coverage', icon: 'PartyPopper' },
  { id: 'maternity', name: 'Maternity Shoot', icon: 'HeartPulse' },
  { id: 'video', name: 'Videography', icon: 'Video' },
  { id: 'candid', name: 'Candid Photography', icon: 'Smile' },
];
