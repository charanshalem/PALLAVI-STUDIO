import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { GALLERY_CATEGORIES, type GalleryItem } from '@/types';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';
import { X, Loader2, Calendar } from 'lucide-react';

export default function Gallery() {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [filtered, setFiltered] = useState<GalleryItem[]>([]);
  const [activeCategory, setActiveCategory] = useState('All');
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);

  const fetchGallery = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('gallery_items')
      .select('*')
      .order('sort_order', { ascending: true })
      .order('created_at', { ascending: false });
    if (error) {
      console.error('Error fetching gallery:', error);
    } else if (data) {
      setItems(data);
      setFiltered(data);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchGallery();
  }, [fetchGallery]);

  useEffect(() => {
    if (activeCategory === 'All') {
      setFiltered(items);
    } else {
      setFiltered(items.filter((item) => item.category === activeCategory));
    }
  }, [activeCategory, items]);

  return (
    <>
      <SEO
        title="Gallery"
        description="Explore the stunning portfolio of SRI PALLAVI STUDIO. Browse our collection of wedding, portrait, pre-wedding, kids, and event photography."
        keywords="photography gallery, wedding photos, portrait gallery, SRI PALLAVI STUDIO portfolio, Pithapuram photographer gallery"
      />

      {/* Page Header */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-gray-950 to-gray-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://images.pexels.com/photos/11234300/pexels-photo-11234300.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 to-gray-900/90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Our Portfolio</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Gallery</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Explore our collection of beautifully captured moments across weddings, portraits, events, and more
            </p>
          </Reveal>
        </div>
      </section>

      {/* Category Filter */}
      <section className="sticky top-20 z-30 bg-gray-950/95 backdrop-blur-md border-y border-white/5 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {GALLERY_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-300 ${
                  activeCategory === cat
                    ? 'bg-amber-500 text-gray-900'
                    : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-amber-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 bg-gray-900 min-h-[50vh]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-gray-500 text-lg">No photos in this category yet. Check back soon!</p>
            </div>
          ) : (
            <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-4 space-y-4">
              {filtered.map((item, i) => (
                <Reveal key={item.id} delay={(i % 6) * 60} direction="scale">
                  <div
                    onClick={() => setSelectedItem(item)}
                    className="group relative overflow-hidden rounded-2xl break-inside-avoid cursor-pointer mb-4"
                  >
                    <img
                      src={item.media_url}
                      alt={item.title}
                      className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                    <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-400">
                      <span className="text-amber-400 text-xs uppercase tracking-wider">{item.category}</span>
                      <h3 className="text-white font-semibold text-sm mt-0.5">{item.title}</h3>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Lightbox */}
      {selectedItem && (
        <div
          className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4"
          onClick={() => setSelectedItem(null)}
        >
          <button
            className="absolute top-6 right-6 text-white/60 hover:text-white transition-colors z-10"
            onClick={() => setSelectedItem(null)}
          >
            <X className="w-8 h-8" />
          </button>
          <div className="max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
            <img
              src={selectedItem.media_url}
              alt={selectedItem.title}
              className="w-full max-h-[80vh] object-contain rounded-lg"
            />
            <div className="text-center mt-4">
              <span className="text-amber-400 text-xs uppercase tracking-wider">{selectedItem.category}</span>
              <h3 className="text-white text-xl font-semibold mt-1">{selectedItem.title}</h3>
              {selectedItem.description && (
                <p className="text-gray-400 text-sm mt-2 max-w-xl mx-auto">{selectedItem.description}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
