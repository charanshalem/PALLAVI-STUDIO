import { useState } from 'react';
import { Link } from 'react-router-dom';
import StudioEmblem from '@/components/StudioEmblem';
import { supabase } from '@/lib/supabase';
import { isAllowedAdminEmail, isStudioAdmin, resolveAdminEmail } from '@/lib/admin';

export default function ForgotPassword() {
  const [identity, setIdentity] = useState('');
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [step, setStep] = useState<'send' | 'verify' | 'password' | 'done'>('send');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const inputClass = 'mt-2 w-full rounded-xl border border-white/20 bg-gray-900 p-3 text-white';

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (step === 'send') {
        const target = resolveAdminEmail(identity);
        if (!isAllowedAdminEmail(target)) throw new Error('Use one of the authorized admin accounts.');
        const { error } = await supabase.auth.resetPasswordForEmail(target, {
          redirectTo: `${window.location.origin}/admin/reset-password`,
        });
        if (error) throw error;
        setEmail(target);
        setStep('verify');
      } else if (step === 'verify') {
        const { data, error } = await supabase.auth.verifyOtp({ email, token: token.trim(), type: 'recovery' });
        if (error) throw error;
        if (!isStudioAdmin(data.user)) {
          await supabase.auth.signOut();
          throw new Error('This account has not been authorized as a studio administrator.');
        }
        setToken('');
        setStep('password');
      } else if (step === 'password') {
        if (password.length < 10) throw new Error('Use at least 10 characters for your new password.');
        if (password !== confirm) throw new Error('The passwords do not match.');
        const { data: account, error: accountError } = await supabase.auth.getUser();
        if (accountError || !isStudioAdmin(account.user) || account.user?.email?.toLowerCase() !== email) {
          setStep('send');
          throw new Error('Your recovery session has expired. Request a new code.');
        }
        const { error } = await supabase.auth.updateUser({ password });
        if (error) throw error;
        setPassword('');
        setConfirm('');
        await supabase.auth.signOut({ scope: 'global' });
        setStep('done');
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Unable to complete the request. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-950 px-4 py-12 flex items-center justify-center text-white">
      <section className="w-full max-w-md rounded-3xl border border-white/10 bg-white/5 p-8">
        <div className="text-center"><StudioEmblem size="lg" /><h1 className="mt-5 text-2xl font-bold">Reset or change password</h1>
          <p className="mt-2 text-sm text-gray-400">Sri Pallavi Studio · Admin accounts only</p></div>
        {step === 'done' ? <p role="status" className="my-6 text-amber-400">Password changed. Sign in with your new password.</p> : (
          <form onSubmit={submit} className="mt-6 space-y-5">
            {step === 'send' && <label className="block">Admin username or email<input className={inputClass} required autoComplete="username" value={identity} onChange={e => setIdentity(e.target.value)} placeholder="suresh or charan" /></label>}
            {step === 'verify' && <><p className="text-sm text-gray-300">Enter the recovery code sent to {email}. Check your spam folder too.</p><label className="block">Email OTP<input className={inputClass} required inputMode="numeric" autoComplete="one-time-code" value={token} onChange={e => setToken(e.target.value)} /></label></>}
            {step === 'password' && <><label className="block">New password<input type="password" className={inputClass} minLength={10} required autoComplete="new-password" value={password} onChange={e => setPassword(e.target.value)} /></label><label className="block">Confirm new password<input type="password" className={inputClass} minLength={10} required autoComplete="new-password" value={confirm} onChange={e => setConfirm(e.target.value)} /></label></>}
            {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
            <button disabled={busy} className="w-full rounded-xl bg-amber-400 p-3 font-semibold text-gray-950 disabled:opacity-50">{busy ? 'Please wait…' : step === 'send' ? 'Send email OTP' : step === 'verify' ? 'Verify OTP' : 'Save new password'}</button>
            {step === 'verify' && <button type="button" disabled={busy} onClick={() => { setStep('send'); setToken(''); setError(''); }} className="text-sm text-amber-400">Request another code or change account</button>}
          </form>
        )}
        <Link to="/admin" className="mt-6 block text-center text-sm text-gray-400">Back to admin login</Link>
      </section>
    </div>
  );
}
