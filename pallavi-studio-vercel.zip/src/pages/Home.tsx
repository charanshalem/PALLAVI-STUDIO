import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Heart, Camera, User, Baby, PartyPopper, Video, Smile,
  Star, ArrowRight, Quote, MapPin, Sparkles, Award, Clock, Calendar,
} from 'lucide-react';
import { supabase, STUDIO_INFO } from '@/lib/supabase';
import type { GalleryItem, Testimonial } from '@/types';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';
import BeforeAfterSlider from '@/components/BeforeAfterSlider';

const services = [
  { icon: Heart, title: 'Wedding Photography', desc: 'Timeless captures of your sacred bond' },
  { icon: Camera, title: 'Pre-Wedding Shoots', desc: 'Romantic moments before the big day' },
  { icon: User, title: 'Portrait Sessions', desc: 'Express yourself in stunning portraits' },
  { icon: Baby, title: 'Kids Photography', desc: 'Cherish the innocence of childhood' },
  { icon: PartyPopper, title: 'Event Coverage', desc: 'Every celebration, beautifully documented' },
  { icon: Video, title: 'Cinematic Videography', desc: 'Stories told through motion and music' },
];

const stats = [
  { value: '500+', label: 'Weddings Shot' },
  { value: '10+', label: 'Years Experience' },
  { value: '1000+', label: 'Happy Clients' },
  { value: '50K+', label: 'Photos Delivered' },
];

export default function Home() {
  const [featuredItems, setFeaturedItems] = useState<GalleryItem[]>([]);
  const [latestItems, setLatestItems] = useState<GalleryItem[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);

  useEffect(() => {
    (async () => {
      const { data: gallery } = await supabase
        .from('gallery_items')
        .select('*')
        .eq('is_featured', true)
        .order('sort_order', { ascending: true })
        .limit(6);
      if (gallery) setFeaturedItems(gallery);

      const { data: latest } = await supabase
        .from('gallery_items')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(8);
      if (latest) setLatestItems(latest);

      const { data: test } = await supabase
        .from('testimonials')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(3);
      if (test) setTestimonials(test);
    })();
  }, []);

  return (
    <>
      <SEO />
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/39352696/pexels-photo-39352696.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Wedding photography"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-gray-950" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent" />
        </div>

        {/* Animated particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-amber-400/40 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `float ${5 + Math.random() * 10}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 5}s`,
              }}
            />
          ))}
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
          <Reveal direction="up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-sm mb-6">
              <Sparkles className="w-4 h-4" />
              <span>Professional Photography & Videography</span>
            </div>
          </Reveal>

          <Reveal direction="up" delay={150}>
            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-white mb-4 leading-tight">
              SRI PALLAVI
              <span className="block bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 bg-clip-text text-transparent">
                STUDIO
              </span>
            </h1>
          </Reveal>

          <Reveal direction="up" delay={300}>
            <p className="text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
              {STUDIO_INFO.tagline}. We turn your most precious moments into timeless works of art.
            </p>
          </Reveal>

          <Reveal direction="up" delay={450}>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/booking"
                className="group inline-flex items-center justify-center gap-2 px-8 py-4 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold rounded-full transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/30 hover:scale-105"
              >
                Book a Session
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/gallery"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white font-semibold rounded-full border border-white/20 transition-all duration-300 hover:scale-105"
              >
                Explore Our Work
              </Link>
            </div>
          </Reveal>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-amber-400 rounded-full animate-bounce" />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gray-950 py-16 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <Reveal key={stat.label} direction="scale" delay={i * 100}>
                <div className="text-center">
                  <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent mb-2">
                    {stat.value}
                  </div>
                  <div className="text-gray-400 text-sm uppercase tracking-wider">{stat.label}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-gradient-to-b from-gray-950 to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center mb-16">
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">What We Offer</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Our Services</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              From weddings to candid moments, we offer a full range of photography and videography services
            </p>
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, i) => (
              <Reveal key={service.title} delay={i * 100} direction="up">
                <div className="group relative p-8 bg-white/5 rounded-2xl border border-white/10 hover:border-amber-500/30 transition-all duration-400 hover:bg-white/[0.07] overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-all duration-500" />
                  <div className="relative">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-700/10 flex items-center justify-center mb-5 group-hover:from-amber-500/30 group-hover:to-amber-700/20 transition-all duration-400">
                      <service.icon className="w-7 h-7 text-amber-400 group-hover:scale-110 transition-transform duration-300" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">{service.desc}</p>
                    <Link
                      to="/services"
                      className="inline-flex items-center gap-1 text-amber-400 text-sm mt-4 group/link"
                    >
                      Learn more
                      <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                    </Link>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Gallery Section */}
      <section className="py-24 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center mb-16">
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Our Work</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Featured Gallery</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">A glimpse of the beautiful moments we've captured</p>
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredItems.map((item, i) => (
              <Reveal key={item.id} delay={i * 80} direction="scale">
                <div className="group relative overflow-hidden rounded-2xl aspect-[4/3] cursor-pointer">
                  <img
                    src={item.media_url}
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-400" />
                  <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-2 group-hover:translate-y-0 transition-transform duration-400">
                    <span className="text-amber-400 text-xs uppercase tracking-wider">{item.category}</span>
                    <h3 className="text-white font-semibold text-lg mt-1">{item.title}</h3>
                    {item.description && (
                      <p className="text-gray-300 text-sm mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-400">
                        {item.description}
                      </p>
                    )}
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              to="/gallery"
              className="inline-flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-amber-500 text-white hover:text-gray-900 font-medium rounded-full border border-white/10 hover:border-amber-500 transition-all duration-300"
            >
              View Full Gallery
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Latest Shoots Section */}
      <section className="py-24 bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center mb-16">
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Fresh From The Studio</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Latest Shoots</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Our most recent photography sessions, updated regularly
            </p>
          </Reveal>

          {latestItems.length === 0 ? (
            <div className="text-center text-gray-500 py-12">Loading latest shoots...</div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {latestItems.map((item, i) => (
                <Reveal key={item.id} delay={(i % 4) * 80} direction="scale">
                  <Link to="/gallery" className="group relative overflow-hidden rounded-xl aspect-square block">
                    <img
                      src={item.media_url}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                    <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-400">
                      <span className="text-amber-400 text-[10px] uppercase tracking-wider">{item.category}</span>
                      <p className="text-white text-xs font-medium truncate">{item.title}</p>
                    </div>
                    {i < 3 && (
                      <span className="absolute top-2 right-2 px-2 py-0.5 bg-amber-500 text-gray-900 text-[10px] font-bold rounded-full">
                        NEW
                      </span>
                    )}
                  </Link>
                </Reveal>
              ))}
            </div>
          )}

          <div className="text-center mt-10">
            <Link
              to="/gallery"
              className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 text-sm font-medium transition-colors"
            >
              View Full Gallery
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-gradient-to-b from-gray-900 to-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <Reveal direction="left">
              <div className="relative">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <img
                      src="https://images.pexels.com/photos/5804239/pexels-photo-5804239.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Wedding moment"
                      className="rounded-2xl w-full aspect-[3/4] object-cover"
                    />
                    <img
                      src="https://images.pexels.com/photos/8516836/pexels-photo-8516836.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Portrait"
                      className="rounded-2xl w-full aspect-square object-cover"
                    />
                  </div>
                  <div className="space-y-4 pt-8">
                    <img
                      src="https://images.pexels.com/photos/34187944/pexels-photo-34187944.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Kids photography"
                      className="rounded-2xl w-full aspect-square object-cover"
                    />
                    <img
                      src="https://images.pexels.com/photos/8507464/pexels-photo-8507464.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Pre-wedding"
                      className="rounded-2xl w-full aspect-[3/4] object-cover"
                    />
                  </div>
                </div>
                <div className="absolute -bottom-4 -left-4 w-24 h-24 bg-amber-500/20 rounded-full blur-2xl" />
              </div>
            </Reveal>

            <Reveal direction="right">
              <div>
                <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Why Choose Us</p>
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                  Where Every Frame Tells Your Story
                </h2>
                <p className="text-gray-400 mb-8 leading-relaxed">
                  At SRI PALLAVI STUDIO, we believe photography is more than just taking pictures —
                  it's about preserving emotions, telling stories, and creating memories that last
                  generations. Our team combines technical expertise with artistic vision.
                </p>

                <div className="space-y-4">
                  {[
                    { icon: Award, title: 'Award-Winning Quality', desc: 'Recognized for excellence in photography' },
                    { icon: Smile, title: '1000+ Happy Clients', desc: 'Trusted by families across Andhra Pradesh' },
                    { icon: Clock, title: 'On-Time Delivery', desc: 'Quick turnaround without compromising quality' },
                  ].map((item) => (
                    <div key={item.title} className="flex items-start gap-4 group">
                      <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center flex-shrink-0 group-hover:bg-amber-500/20 transition-all">
                        <item.icon className="w-6 h-6 text-amber-400" />
                      </div>
                      <div>
                        <h4 className="text-white font-semibold">{item.title}</h4>
                        <p className="text-gray-400 text-sm">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center mb-16">
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Testimonials</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">What Our Clients Say</h2>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <Reveal key={t.id} delay={i * 120} direction="up">
                <div className="relative p-8 bg-white/5 rounded-2xl border border-white/10 hover:border-amber-500/20 transition-all duration-400 h-full">
                  <Quote className="w-10 h-10 text-amber-500/30 mb-4" />
                  <p className="text-gray-300 text-sm leading-relaxed mb-6">"{t.content}"</p>
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, idx) => (
                      <Star
                        key={idx}
                        className={`w-4 h-4 ${idx < t.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-700'}`}
                      />
                    ))}
                  </div>
                  <p className="text-white font-semibold">{t.name}</p>
                  {t.event_type && <p className="text-gray-500 text-xs">{t.event_type}</p>}
                </div>
              </Reveal>
            ))}
          </div>

          <div className="text-center mt-10">
            <Link
              to="/reviews"
              className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 text-sm font-medium transition-colors"
            >
              Read More Reviews
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Before/After Photo Restoration Section */}
      <section className="py-24 bg-gradient-to-b from-gray-900 to-gray-950">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Photo Restoration</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Revive Your Old Memories
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Drag the slider to see the transformation. We restore damaged, faded, and old photographs to their former glory.
            </p>
          </Reveal>

          <Reveal direction="scale">
            <div className="max-w-3xl mx-auto">
              <BeforeAfterSlider
                beforeImage="https://images.pexels.com/photos/33573413/pexels-photo-33573413.jpeg?auto=compress&cs=tinysrgb&w=1260"
                afterImage="https://images.pexels.com/photos/39106940/pexels-photo-39106940.jpeg?auto=compress&cs=tinysrgb&w=1260"
                title="Black & White to Color Restoration"
                description="We carefully colorize and enhance old photographs while preserving their original character and emotion."
              />
            </div>
          </Reveal>

          <div className="text-center mt-8">
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-amber-500 text-white hover:text-gray-900 font-medium rounded-full border border-white/10 hover:border-amber-500 transition-all duration-300"
            >
              Restore Your Old Photos
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA / Location Section */}
      <section className="py-24 bg-gradient-to-b from-gray-950 to-gray-900">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Ready to Capture Your Story?
            </h2>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Book your session today and let us create beautiful memories together.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link
                to="/booking"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold rounded-full transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/30 hover:scale-105"
              >
                Book Now
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/5 hover:bg-white/10 text-white font-semibold rounded-full border border-white/10 transition-all duration-300"
              >
                Contact Us
              </Link>
            </div>

            <div className="inline-flex items-center gap-2 text-gray-400 text-sm">
              <MapPin className="w-4 h-4 text-amber-400" />
              <a href={STUDIO_INFO.mapsUrl} target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 transition-colors">
                {STUDIO_INFO.address}
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
