import { useState } from 'react';
import { Calendar, User, Mail, Phone, MessageSquare, Loader2, CheckCircle, Heart, Camera, Baby, PartyPopper, Video, Smile, User as UserIcon } from 'lucide-react';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';
import { supabase } from '@/lib/supabase';

const eventTypes = [
  { value: 'Wedding Photography', label: 'Wedding Photography', icon: Heart },
  { value: 'Pre-Wedding Shoot', label: 'Pre-Wedding Shoot', icon: Camera },
  { value: 'Portrait Session', label: 'Portrait Session', icon: UserIcon },
  { value: 'Kids Photography', label: 'Kids Photography', icon: Baby },
  { value: 'Event Coverage', label: 'Event Coverage', icon: PartyPopper },
  { value: 'Cinematic Videography', label: 'Cinematic Videography', icon: Video },
  { value: 'Candid Photography', label: 'Candid Photography', icon: Smile },
];

export default function Booking() {
  const [form, setForm] = useState({
    name: '', email: '', phone: '', event_type: '', event_date: '', message: '',
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone || !form.event_type) {
      setError('Please fill in all required fields');
      return;
    }
    setLoading(true);
    setError(null);

    const { error: insertError } = await supabase.from('bookings').insert({
      name: form.name,
      email: form.email,
      phone: form.phone,
      event_type: form.event_type,
      event_date: form.event_date || null,
      message: form.message || null,
    });

    setLoading(false);

    if (insertError) {
      setError('Something went wrong. Please try again or call us directly.');
    } else {
      setSuccess(true);
      setForm({ name: '', email: '', phone: '', event_type: '', event_date: '', message: '' });
    }
  };

  if (success) {
    return (
      <>
        <SEO title="Booking" description="Book your photography or videography session with SRI PALLAVI STUDIO in Pithapuram." />
        <section className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-950 to-gray-900 pt-24 pb-12 px-4">
          <Reveal direction="scale">
            <div className="max-w-lg w-full p-8 bg-white/5 rounded-3xl border border-white/10 text-center">
              <CheckCircle className="w-20 h-20 text-amber-400 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-white mb-3">Booking Request Sent!</h1>
              <p className="text-gray-400 mb-8">
                Thank you for choosing SRI PALLAVI STUDIO. We've received your booking request and will
                contact you within 24 hours to confirm the details.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  onClick={() => setSuccess(false)}
                  className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold rounded-full transition-all"
                >
                  Make Another Booking
                </button>
                <a
                  href="/"
                  className="px-6 py-3 bg-white/5 hover:bg-white/10 text-white font-semibold rounded-full border border-white/10 transition-all"
                >
                  Back to Home
                </a>
              </div>
            </div>
          </Reveal>
        </section>
      </>
    );
  }

  return (
    <>
      <SEO
        title="Book a Session"
        description="Book your photography or videography session with SRI PALLAVI STUDIO. Choose from wedding, pre-wedding, portrait, kids, and event photography services in Pithapuram."
        keywords="book photography session, wedding booking Pithapuram, schedule photo shoot, SRI PALLAVI STUDIO booking"
      />

      {/* Header */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-gray-950 to-gray-900 overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img
            src="https://images.pexels.com/photos/27443997/pexels-photo-27443997.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 to-gray-900/90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Reserve Your Date</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Book a Session</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Fill out the form below and we'll get back to you within 24 hours to confirm your booking
            </p>
          </Reveal>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal direction="up">
            <div className="p-8 md:p-10 bg-white/5 rounded-3xl border border-white/10">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Event Type Selection */}
                <div>
                  <label className="block text-gray-300 text-sm font-medium mb-3">
                    Select Service <span className="text-amber-400">*</span>
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {eventTypes.map((type) => (
                      <button
                        key={type.value}
                        type="button"
                        onClick={() => setForm({ ...form, event_type: type.value })}
                        className={`flex flex-col items-center gap-2 p-4 rounded-xl border transition-all duration-300 ${
                          form.event_type === type.value
                            ? 'bg-amber-500/15 border-amber-500/50 text-amber-400'
                            : 'bg-gray-900/50 border-white/10 text-gray-400 hover:border-white/20 hover:text-white'
                        }`}
                      >
                        <type.icon className="w-6 h-6" />
                        <span className="text-xs text-center">{type.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-300 text-sm mb-2">
                      <User className="w-4 h-4 inline mr-1" /> Name <span className="text-amber-400">*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 text-sm mb-2">
                      <Phone className="w-4 h-4 inline mr-1" /> Phone <span className="text-amber-400">*</span>
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                      placeholder="+91 98765 43210"
                    />
                  </div>
                </div>

                {/* Email & Date */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-300 text-sm mb-2">
                      <Mail className="w-4 h-4 inline mr-1" /> Email <span className="text-amber-400">*</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 text-sm mb-2">
                      <Calendar className="w-4 h-4 inline mr-1" /> Event Date
                    </label>
                    <input
                      type="date"
                      name="event_date"
                      value={form.event_date}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label className="block text-gray-300 text-sm mb-2">
                    <MessageSquare className="w-4 h-4 inline mr-1" /> Additional Details
                  </label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    rows={4}
                    className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors resize-none"
                    placeholder="Tell us about your event, location preferences, number of guests, etc."
                  />
                </div>

                {error && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-amber-500 hover:bg-amber-400 disabled:bg-amber-500/50 text-gray-900 font-semibold rounded-xl transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/20"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Calendar className="w-5 h-5" />
                      Submit Booking Request
                    </>
                  )}
                </button>
              </form>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
