import { useState } from 'react';
import { MapPin, Phone, Mail, Send, Loader2, CheckCircle, MessageCircle, Facebook, Instagram, Youtube } from 'lucide-react';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';
import { supabase, STUDIO_INFO } from '@/lib/supabase';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      setError('Please fill in all required fields');
      return;
    }
    setLoading(true);
    setError(null);

    const { error: insertError } = await supabase.from('messages').insert({
      name: form.name,
      email: form.email,
      phone: form.phone || null,
      subject: form.subject || null,
      message: form.message,
    });

    setLoading(false);

    if (insertError) {
      setError('Something went wrong. Please try again or call us directly.');
    } else {
      setSuccess(true);
      setForm({ name: '', email: '', phone: '', subject: '', message: '' });
    }
  };

  return (
    <>
      <SEO
        title="Contact"
        description="Get in touch with SRI PALLAVI STUDIO. Located near Old Police Station, Pithapuram. Call us or send a message to book your photography session."
        keywords="contact SRI PALLAVI STUDIO, photography booking Pithapuram, photographer contact Andhra Pradesh"
      />

      {/* Header */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-gray-950 to-gray-900 overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img
            src="https://images.pexels.com/photos/5577960/pexels-photo-5577960.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 to-gray-900/90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Get in Touch</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Contact Us</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Have a question or want to book a session? We'd love to hear from you
            </p>
          </Reveal>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <Reveal direction="left">
              <div className="space-y-6">
                <div>
                  <h2 className="text-3xl font-bold text-white mb-4">Let's Talk</h2>
                  <p className="text-gray-400 leading-relaxed">
                    Whether you're planning a wedding, need a portrait session, or have a question about
                    our services, we're here to help. Reach out through any of the channels below or fill
                    out the contact form.
                  </p>
                </div>

                <div className="space-y-4">
                  <a
                    href={STUDIO_INFO.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-start gap-4 p-5 bg-white/5 rounded-2xl border border-white/10 hover:border-amber-500/30 transition-all duration-300"
                  >
                    <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center flex-shrink-0 group-hover:bg-amber-500/20 transition-all">
                      <MapPin className="w-6 h-6 text-amber-400" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold mb-1">Our Location</h4>
                      <p className="text-gray-400 text-sm">{STUDIO_INFO.address}</p>
                      <span className="text-amber-400 text-xs mt-1 inline-block">Open in Google Maps →</span>
                    </div>
                  </a>

                  <a
                    href={`tel:${STUDIO_INFO.phone}`}
                    className="group flex items-start gap-4 p-5 bg-white/5 rounded-2xl border border-white/10 hover:border-amber-500/30 transition-all duration-300"
                  >
                    <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center flex-shrink-0 group-hover:bg-amber-500/20 transition-all">
                      <Phone className="w-6 h-6 text-amber-400" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold mb-1">Phone</h4>
                      <p className="text-gray-400 text-sm">{STUDIO_INFO.phone}</p>
                    </div>
                  </a>

                  <a
                    href={`mailto:${STUDIO_INFO.email}`}
                    className="group flex items-start gap-4 p-5 bg-white/5 rounded-2xl border border-white/10 hover:border-amber-500/30 transition-all duration-300"
                  >
                    <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center flex-shrink-0 group-hover:bg-amber-500/20 transition-all">
                      <Mail className="w-6 h-6 text-amber-400" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold mb-1">Email</h4>
                      <p className="text-gray-400 text-sm break-all">{STUDIO_INFO.email}</p>
                    </div>
                  </a>
                </div>

                <div>
                  <h4 className="text-white font-semibold mb-3 text-sm">Follow Us</h4>
                  <div className="flex gap-3">
                    <a href={STUDIO_INFO.socials.instagram} className="w-11 h-11 rounded-full bg-white/5 hover:bg-amber-500 flex items-center justify-center transition-all hover:scale-110 group">
                      <Instagram className="w-5 h-5 text-gray-400 group-hover:text-gray-900" />
                    </a>
                    <a href={STUDIO_INFO.socials.facebook} className="w-11 h-11 rounded-full bg-white/5 hover:bg-amber-500 flex items-center justify-center transition-all hover:scale-110 group">
                      <Facebook className="w-5 h-5 text-gray-400 group-hover:text-gray-900" />
                    </a>
                    <a href={STUDIO_INFO.socials.youtube} className="w-11 h-11 rounded-full bg-white/5 hover:bg-amber-500 flex items-center justify-center transition-all hover:scale-110 group">
                      <Youtube className="w-5 h-5 text-gray-400 group-hover:text-gray-900" />
                    </a>
                    <a href={STUDIO_INFO.socials.whatsapp} className="w-11 h-11 rounded-full bg-white/5 hover:bg-amber-500 flex items-center justify-center transition-all hover:scale-110 group">
                      <MessageCircle className="w-5 h-5 text-gray-400 group-hover:text-gray-900" />
                    </a>
                  </div>
                </div>
              </div>
            </Reveal>

            {/* Contact Form */}
            <Reveal direction="right">
              <div className="p-8 bg-white/5 rounded-3xl border border-white/10">
                {success ? (
                  <div className="flex flex-col items-center justify-center text-center py-12">
                    <CheckCircle className="w-16 h-16 text-amber-400 mb-4" />
                    <h3 className="text-2xl font-bold text-white mb-2">Message Sent!</h3>
                    <p className="text-gray-400 mb-6">
                      Thank you for reaching out. We'll get back to you as soon as possible.
                    </p>
                    <button
                      onClick={() => setSuccess(false)}
                      className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold rounded-full transition-all"
                    >
                      Send Another Message
                    </button>
                  </div>
                ) : (
                  <>
                    <h3 className="text-2xl font-bold text-white mb-6">Send Us a Message</h3>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-300 text-sm mb-2">Name *</label>
                          <input
                            type="text"
                            name="name"
                            value={form.name}
                            onChange={handleChange}
                            required
                            className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                            placeholder="Your name"
                          />
                        </div>
                        <div>
                          <label className="block text-gray-300 text-sm mb-2">Email *</label>
                          <input
                            type="email"
                            name="email"
                            value={form.email}
                            onChange={handleChange}
                            required
                            className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                            placeholder="your@email.com"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-300 text-sm mb-2">Phone</label>
                          <input
                            type="tel"
                            name="phone"
                            value={form.phone}
                            onChange={handleChange}
                            className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                            placeholder="Your phone number"
                          />
                        </div>
                        <div>
                          <label className="block text-gray-300 text-sm mb-2">Subject</label>
                          <input
                            type="text"
                            name="subject"
                            value={form.subject}
                            onChange={handleChange}
                            className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors"
                            placeholder="What's this about?"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-gray-300 text-sm mb-2">Message *</label>
                        <textarea
                          name="message"
                          value={form.message}
                          onChange={handleChange}
                          required
                          rows={5}
                          className="w-full px-4 py-3 bg-gray-900/50 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:border-amber-500/50 focus:outline-none transition-colors resize-none"
                          placeholder="Tell us about your event or question..."
                        />
                      </div>

                      {error && (
                        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">
                          {error}
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-amber-500 hover:bg-amber-400 disabled:bg-amber-500/50 text-gray-900 font-semibold rounded-xl transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/20"
                      >
                        {loading ? (
                          <>
                            <Loader2 className="w-5 h-5 animate-spin" />
                            Sending...
                          </>
                        ) : (
                          <>
                            <Send className="w-5 h-5" />
                            Send Message
                          </>
                        )}
                      </button>
                    </form>
                  </>
                )}
              </div>
            </Reveal>
          </div>

          {/* Map */}
          <Reveal direction="scale" className="mt-12">
            <div className="rounded-3xl overflow-hidden border border-white/10">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30450.5!2d82.25!3d17.1167!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a3a3a%3A0x0!2zUGl0aGFwdXJhbSwgQW5kaHJhIFByYWRlc2g!5e0!3m2!1sen!2sin!4v1700000000000"
                width="100%"
                height="400"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="SRI PALLAVI STUDIO Location Map"
              />
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
