import { useState } from 'react';
import { ChevronDown, Star } from 'lucide-react';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';

const faqs = [
  {
    q: 'How do I book a photography session?',
    a: 'You can book a session through our online booking form, by calling us directly, or via WhatsApp. We recommend booking at least 2-3 weeks in advance for weddings and large events.',
  },
  {
    q: 'What areas do you serve?',
    a: 'We are based in Pithapuram, Andhra Pradesh, and serve clients across the region. For destination weddings and special projects, we travel throughout India.',
  },
  {
    q: 'How long does it take to receive my photos?',
    a: 'For portrait and event sessions, edited photos are typically delivered within 7-10 days. For weddings, the full gallery is delivered within 3-4 weeks, with a sneak peek provided within 48 hours.',
  },
  {
    q: 'Do you provide both photos and videos?',
    a: 'Yes! We offer both photography and cinematic videography services. You can book them separately or as a combined package for a complete coverage experience.',
  },
  {
    q: 'Can I customize a photography package?',
    a: 'Absolutely. All our packages are customizable. Contact us with your specific requirements and we will create a personalized quote that fits your needs and budget.',
  },
  {
    q: 'Do you offer photo albums and prints?',
    a: 'Yes, we offer premium wedding albums, photo prints, custom photo gifts, and photo framing services. Our albums are hand-crafted using archival-quality materials.',
  },
  {
    q: 'What happens if the event date changes?',
    a: 'We understand plans can change. Contact us as soon as possible and we will do our best to accommodate your new date, subject to availability.',
  },
  {
    q: 'Do you offer photo restoration services?',
    a: 'Yes, we specialize in restoring old and damaged photographs. We can repair tears, remove blemishes, colorize black-and-white photos, and enhance faded images while preserving the original character.',
  },
  {
    q: 'What payment methods do you accept?',
    a: 'We accept bank transfers, UPI payments, cash, and major credit/debit cards. A booking advance is required to confirm your date, with the balance due on or before the event day.',
  },
  {
    q: 'Do you provide raw/unedited photos?',
    a: 'We deliver professionally edited photos that represent our studio quality. Raw files are available upon request for certain packages — please discuss this during booking.',
  },
];

function FAQItem({ item, isOpen, onToggle }: { item: { q: string; a: string }; isOpen: boolean; onToggle: () => void }) {
  return (
    <div className="border-b border-white/10">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between py-5 text-left group"
      >
        <span className={`font-medium pr-4 transition-colors ${isOpen ? 'text-amber-400' : 'text-white group-hover:text-amber-300'}`}>
          {item.q}
        </span>
        <ChevronDown
          className={`w-5 h-5 flex-shrink-0 transition-all duration-300 ${
            isOpen ? 'text-amber-400 rotate-180' : 'text-gray-500 group-hover:text-amber-300'
          }`}
        />
      </button>
      <div
        className={`overflow-hidden transition-all duration-400 ${
          isOpen ? 'max-h-48 pb-5' : 'max-h-0'
        }`}
      >
        <p className="text-gray-400 text-sm leading-relaxed">{item.a}</p>
      </div>
    </div>
  );
}

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <>
      <SEO
        title="FAQ"
        description="Frequently asked questions about SRI PALLAVI STUDIO photography services, booking process, delivery timelines, packages, and more in Pithapuram."
        keywords="photography FAQ, wedding photography questions, photo studio FAQ Pithapuram, booking photography session"
      />

      <section className="relative pt-32 pb-16 bg-gradient-to-b from-gray-950 to-gray-900 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img
            src="https://images.pexels.com/photos/34694355/pexels-photo-34694355.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 to-gray-900/90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Got Questions?</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">FAQ</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Everything you need to know about our photography services, booking process, and delivery
            </p>
          </Reveal>
        </div>
      </section>

      <section className="py-20 bg-gray-900">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="bg-white/5 rounded-2xl border border-white/10 px-6 sm:px-8 divide-y divide-white/0">
              {faqs.map((faq, i) => (
                <FAQItem
                  key={i}
                  item={faq}
                  isOpen={openIndex === i}
                  onToggle={() => setOpenIndex(openIndex === i ? null : i)}
                />
              ))}
            </div>
          </Reveal>

          <Reveal className="mt-12 text-center">
            <p className="text-gray-400 mb-4">Still have questions?</p>
            <a
              href="/contact"
              className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold rounded-full transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/30"
            >
              Get in Touch
            </a>
          </Reveal>
        </div>
      </section>
    </>
  );
}
