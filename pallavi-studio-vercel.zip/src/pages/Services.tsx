import { Link } from 'react-router-dom';
import {
  Heart, Camera, User, Baby, PartyPopper, Video, Smile, HeartPulse,
  ArrowRight, Check, Sparkles, MessageCircle,
} from 'lucide-react';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';
import { STUDIO_INFO } from '@/lib/supabase';

const waEnquire = (serviceName: string) => {
  const msg = encodeURIComponent(`Hello ${STUDIO_INFO.name}! I'm interested in your ${serviceName} service. Could you please share more details?`);
  window.open(`https://wa.me/${STUDIO_INFO.whatsapp}?text=${msg}`, '_blank');
};

const services = [
  {
    icon: Heart,
    title: 'Wedding Photography',
    desc: 'Complete coverage of your wedding day — from the morning preparations to the final farewell. We capture every ritual, every emotion, every smile.',
    features: ['Full-day coverage', 'Traditional & candid shots', 'Pre-wedding session included', 'Premium album delivery'],
    image: 'https://images.pexels.com/photos/20518451/pexels-photo-20518451.jpeg?auto=compress&cs=tinysrgb&w=1260',
  },
  {
    icon: Camera,
    title: 'Pre-Wedding Shoot',
    desc: 'Celebrate your love story before the big day with a romantic pre-wedding photoshoot at your chosen location.',
    features: ['Location of your choice', '2-3 hour session', 'Multiple outfit changes', '50+ edited photos'],
    image: 'https://images.pexels.com/photos/8507464/pexels-photo-8507464.jpeg?auto=compress&cs=tinysrgb&w=1260',
  },
  {
    icon: User,
    title: 'Portrait Sessions',
    desc: 'Express yourself with stunning portrait photography. Whether it\'s for professional use or personal keepsakes, we bring out your best.',
    features: ['Studio & outdoor options', 'Professional lighting', 'Multiple poses', 'High-resolution delivery'],
    image: 'https://images.pexels.com/photos/38804371/pexels-photo-38804371.jpeg?auto=compress&cs=tinysrgb&w=1260',
  },
  {
    icon: Baby,
    title: 'Kids Photography',
    desc: 'Capture the innocence and joy of childhood with our specialized kids photography sessions.',
    features: ['Safe, fun environment', 'Props & themes available', 'Family shots included', 'Quick delivery'],
    image: 'https://images.pexels.com/photos/34187944/pexels-photo-34187944.jpeg?auto=compress&cs=tinysrgb&w=1260',
  },
  {
    icon: PartyPopper,
    title: 'Event Coverage',
    desc: 'From birthdays to corporate events, we document every important moment with professionalism and creativity.',
    features: ['Full event coverage', 'Candid & formal shots', 'Same-day preview photos', 'Online gallery for guests'],
    image: 'https://images.pexels.com/photos/1503520/pexels-photo-1503520.jpeg?auto=compress&cs=tinysrgb&w=1260',
  },
  {
    icon: Video,
    title: 'Cinematic Videography',
    desc: 'Tell your story through beautiful cinematic videos — highlight reels, full ceremony films, and everything in between.',
    features: ['4K cinematic quality', 'Highlight reel included', 'Professional editing', 'Music & sound design'],
    image: 'https://images.pexels.com/photos/5577960/pexels-photo-5577960.jpeg?auto=compress&cs=tinysrgb&w=1260',
  },
];

const pricingPackages = [
  {
    name: 'Essential',
    price: 'Starting from ₹15,000',
    desc: 'Perfect for small events and portrait sessions',
    features: ['3 hours of coverage', '100+ edited photos', 'Online gallery', 'Digital delivery'],
    highlighted: false,
  },
  {
    name: 'Premium',
    price: 'Starting from ₹35,000',
    desc: 'Most popular for weddings and big events',
    features: ['Full-day coverage', '300+ edited photos', 'Pre-wedding session', 'Premium album', 'Highlight video'],
    highlighted: true,
  },
  {
    name: 'Cinematic',
    price: 'Starting from ₹60,000',
    desc: 'Complete coverage with cinematic videography',
    features: ['2-day coverage', '500+ edited photos', 'Cinematic film (4K)', 'Premium album', 'Drone shots', 'Same-day edit'],
    highlighted: false,
  },
];

export default function Services() {
  return (
    <>
      <SEO
        title="Services"
        description="SRI PALLAVI STUDIO offers wedding photography, pre-wedding shoots, portraits, kids photography, event coverage, and cinematic videography in Pithapuram, Andhra Pradesh."
        keywords="photography services Pithapuram, wedding photographer, pre-wedding shoot, portrait photography, event videography, SRI PALLAVI STUDIO services"
      />

      {/* Header */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-gray-950 to-gray-900 overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img
            src="https://images.pexels.com/photos/18880006/pexels-photo-18880006.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 to-gray-900/90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">What We Do</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Our Services</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Professional photography and videography services tailored to capture your most precious moments
            </p>
          </Reveal>
        </div>
      </section>

      {/* Services List */}
      <section className="py-24 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
          {services.map((service, i) => (
            <div
              key={service.title}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                i % 2 === 1 ? 'lg:grid-flow-col-dense' : ''
              }`}
            >
              <Reveal direction={i % 2 === 0 ? 'left' : 'right'} className={i % 2 === 1 ? 'lg:col-start-2' : ''}>
                <div className="relative group overflow-hidden rounded-3xl">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full aspect-[4/3] object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  <div className="absolute top-4 left-4 w-14 h-14 rounded-xl bg-amber-500/90 backdrop-blur flex items-center justify-center">
                    <service.icon className="w-7 h-7 text-gray-900" />
                  </div>
                </div>
              </Reveal>

              <Reveal direction={i % 2 === 0 ? 'right' : 'left'} className={i % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}>
                <div>
                  <h2 className="text-3xl font-bold text-white mb-4">{service.title}</h2>
                  <p className="text-gray-400 mb-6 leading-relaxed">{service.desc}</p>
                  <ul className="space-y-3 mb-8">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-3">
                        <div className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                          <Check className="w-3 h-3 text-amber-400" />
                        </div>
                        <span className="text-gray-300 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap gap-3">
                    <Link
                      to="/booking"
                      className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500/10 hover:bg-amber-500 text-amber-400 hover:text-gray-900 font-medium rounded-full border border-amber-500/30 hover:border-amber-500 transition-all duration-300 group"
                    >
                      Book This Service
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </Link>
                    <button
                      onClick={() => waEnquire(service.title)}
                      className="inline-flex items-center gap-2 px-6 py-3 bg-green-500/10 hover:bg-green-500 text-green-400 hover:text-white font-medium rounded-full border border-green-500/30 hover:border-green-500 transition-all duration-300"
                    >
                      <MessageCircle className="w-5 h-5" />
                      WhatsApp Enquiry
                    </button>
                  </div>
                </div>
              </Reveal>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="py-24 bg-gradient-to-b from-gray-900 to-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center mb-16">
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Pricing</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Packages</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Transparent pricing for every need. All packages are customizable — contact us for a personalized quote.
            </p>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {pricingPackages.map((pkg, i) => (
              <Reveal key={pkg.name} delay={i * 120} direction="up">
                <div
                  className={`relative p-8 rounded-2xl border transition-all duration-400 h-full ${
                    pkg.highlighted
                      ? 'bg-gradient-to-b from-amber-500/15 to-gray-900 border-amber-500/50 shadow-xl shadow-amber-500/10 lg:scale-105'
                      : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                >
                  {pkg.highlighted && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-amber-500 text-gray-900 text-xs font-bold rounded-full flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Most Popular
                    </div>
                  )}
                  <h3 className="text-2xl font-bold text-white mb-2">{pkg.name}</h3>
                  <p className="text-amber-400 font-semibold mb-2">{pkg.price}</p>
                  <p className="text-gray-500 text-sm mb-6">{pkg.desc}</p>
                  <ul className="space-y-3 mb-8">
                    {pkg.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-300 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/booking"
                    className={`block w-full py-3 rounded-full text-center font-semibold transition-all duration-300 ${
                      pkg.highlighted
                        ? 'bg-amber-500 hover:bg-amber-400 text-gray-900'
                        : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
                    }`}
                  >
                    Book Now
                  </Link>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal className="text-center mt-12">
            <p className="text-gray-500 text-sm">
              Need something custom? <Link to="/contact" className="text-amber-400 hover:underline">Contact us</Link> for a personalized quote.
            </p>
          </Reveal>
        </div>
      </section>
    </>
  );
}
