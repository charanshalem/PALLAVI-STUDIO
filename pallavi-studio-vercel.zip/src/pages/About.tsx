import { Link } from 'react-router-dom';
import { Camera, Award, Heart, Users, ArrowRight, MapPin, Star } from 'lucide-react';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';
import { STUDIO_INFO } from '@/lib/supabase';

const teamValues = [
  { icon: Heart, title: 'Passion', desc: 'We pour our hearts into every shoot, treating each event as our own family celebration.' },
  { icon: Award, title: 'Excellence', desc: 'Award-winning photography with attention to every detail, from lighting to composition.' },
  { icon: Users, title: 'Connection', desc: 'We build genuine connections with our clients, making them feel comfortable and natural.' },
  { icon: Camera, title: 'Creativity', desc: 'Every shoot is unique. We bring fresh ideas and artistic vision to capture your story.' },
];

export default function About() {
  return (
    <>
      <SEO
        title="About Us"
        description="Learn about SRI PALLAVI STUDIO — a premier photography studio in Pithapuram, Andhra Pradesh. With over 10 years of experience, we capture weddings, portraits, and events with artistry."
        keywords="about SRI PALLAVI STUDIO, photography studio Pithapuram, photographer Andhra Pradesh, wedding photographer India"
      />

      {/* Header */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-gray-950 to-gray-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://images.pexels.com/photos/28277575/pexels-photo-28277575.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 to-gray-900/90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Our Story</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">About Us</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Capturing life's beautiful moments with passion, creativity, and professionalism
            </p>
          </Reveal>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <Reveal direction="left">
              <div className="relative">
                <img
                  src="https://images.pexels.com/photos/36697247/pexels-photo-36697247.jpeg?auto=compress&cs=tinysrgb&w=1260"
                  alt="SRI PALLAVI STUDIO at work"
                  className="rounded-3xl w-full aspect-[4/5] object-cover"
                />
                <div className="absolute -bottom-6 -right-6 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl" />
                <div className="absolute -top-4 -left-4 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl" />
              </div>
            </Reveal>

            <Reveal direction="right">
              <div>
                <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Our Journey</p>
                <h2 className="text-4xl font-bold text-white mb-6">
                  A Decade of Capturing Memories
                </h2>
                <div className="space-y-4 text-gray-400 leading-relaxed">
                  <p>
                    SRI PALLAVI STUDIO was founded with a simple vision: to capture life's most precious
                    moments in a way that tells a story. What started as a small passion project has grown
                    into one of Pithapuram's most trusted photography studios.
                  </p>
                  <p>
                    Over the past 10+ years, we've photographed more than 500 weddings, 1000+ portrait sessions,
                    and countless events. Each project has taught us something new about the art of photography
                    and the beauty of human connection.
                  </p>
                  <p>
                    Based near the Old Police Station in Pithapuram, we serve clients across Andhra Pradesh
                    and beyond. Our team combines traditional techniques with modern creativity to deliver
                    photographs that are both timeless and contemporary.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-8">
                  <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                    <div className="text-3xl font-bold text-amber-400">10+</div>
                    <div className="text-gray-500 text-sm">Years of Experience</div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                    <div className="text-3xl font-bold text-amber-400">1000+</div>
                    <div className="text-gray-500 text-sm">Happy Clients</div>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-gradient-to-b from-gray-900 to-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center mb-16">
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">What Drives Us</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Our Core Values</h2>
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamValues.map((value, i) => (
              <Reveal key={value.title} delay={i * 100} direction="up">
                <div className="group p-6 bg-white/5 rounded-2xl border border-white/10 hover:border-amber-500/30 transition-all duration-400 h-full text-center">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-700/10 flex items-center justify-center mx-auto mb-4 group-hover:from-amber-500/30 group-hover:to-amber-700/20 transition-all">
                    <value.icon className="w-8 h-8 text-amber-400" />
                  </div>
                  <h3 className="text-white font-semibold text-lg mb-2">{value.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{value.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section className="py-24 bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center mb-12">
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Visit Us</p>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Our Studio</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Located in the heart of Pithapuram, we'd love to welcome you to our studio
            </p>
          </Reveal>

          <Reveal direction="scale">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
              <div className="lg:col-span-2 rounded-2xl overflow-hidden border border-white/10 min-h-[400px]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30450.5!2d82.25!3d17.1167!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a3a3a%3A0x0!2zUGl0aGFwdXJhbSwgQW5kaHJhIFByYWRlc2g!5e0!3m2!1sen!2sin!4v1700000000000"
                  width="100%"
                  height="100%"
                  style={{ border: 0, minHeight: '400px' }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="SRI PALLAVI STUDIO Location"
                />
              </div>
              <div className="p-8 bg-white/5 rounded-2xl border border-white/10 flex flex-col justify-center">
                <MapPin className="w-8 h-8 text-amber-400 mb-4" />
                <h3 className="text-white text-xl font-semibold mb-2">SRI PALLAVI STUDIO</h3>
                <p className="text-gray-400 text-sm mb-4">{STUDIO_INFO.address}</p>
                <a
                  href={STUDIO_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-amber-400 text-sm hover:text-amber-300 transition-colors mb-6"
                >
                  Open in Google Maps
                  <ArrowRight className="w-4 h-4" />
                </a>
                <div className="space-y-2 text-sm text-gray-400">
                  <p><span className="text-gray-500">Phone:</span> {STUDIO_INFO.phone}</p>
                  <p><span className="text-gray-500">Email:</span> {STUDIO_INFO.email}</p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
