import { useEffect, useState } from 'react';
import { Star, Quote, Loader2, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import type { Testimonial } from '@/types';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';
import { STUDIO_INFO } from '@/lib/supabase';

export default function Reviews() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [avgRating, setAvgRating] = useState(0);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('testimonials')
        .select('*')
        .order('created_at', { ascending: false });
      if (data) {
        setTestimonials(data);
        const avg = data.length > 0 ? data.reduce((sum, t) => sum + t.rating, 0) / data.length : 0;
        setAvgRating(avg);
      }
      setLoading(false);
    })();
  }, []);

  return (
    <>
      <SEO
        title="Reviews"
        description="Read authentic customer reviews and testimonials for SRI PALLAVI STUDIO. See why families across Andhra Pradesh trust us for their photography needs."
        keywords="SRI PALLAVI STUDIO reviews, photographer reviews Pithapuram, wedding photography testimonials, customer feedback"
      />

      <section className="relative pt-32 pb-16 bg-gradient-to-b from-gray-950 to-gray-900 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img
            src="https://images.pexels.com/photos/6405786/pexels-photo-6405786.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 to-gray-900/90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">What Clients Say</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Customer Reviews</h1>
            {avgRating > 0 && (
              <div className="flex items-center justify-center gap-2 mt-4">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-6 h-6 ${i < Math.round(avgRating) ? 'text-amber-400 fill-amber-400' : 'text-gray-700'}`}
                    />
                  ))}
                </div>
                <span className="text-gray-300 text-lg font-semibold">{avgRating.toFixed(1)}</span>
                <span className="text-gray-500 text-sm">({testimonials.length} reviews)</span>
              </div>
            )}
          </Reveal>
        </div>
      </section>

      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex justify-center py-20">
              <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
            </div>
          ) : testimonials.length === 0 ? (
            <div className="text-center py-20 text-gray-500">
              <Star className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No reviews yet. Be the first to share your experience!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.map((t, i) => (
                <Reveal key={t.id} delay={(i % 3) * 100} direction="up">
                  <div className="relative p-8 bg-white/5 rounded-2xl border border-white/10 hover:border-amber-500/20 transition-all duration-400 h-full">
                    <Quote className="w-10 h-10 text-amber-500/30 mb-4" />
                    <p className="text-gray-300 text-sm leading-relaxed mb-6">"{t.content}"</p>
                    <div className="flex items-center gap-1 mb-3">
                      {[...Array(5)].map((_, idx) => (
                        <Star
                          key={idx}
                          className={`w-4 h-4 ${idx < t.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-700'}`}
                        />
                      ))}
                    </div>
                    <p className="text-white font-semibold">{t.name}</p>
                    {t.event_type && <p className="text-gray-500 text-xs">{t.event_type}</p>}
                  </div>
                </Reveal>
              ))}
            </div>
          )}

          <Reveal className="mt-12 text-center">
            <div className="p-8 bg-gradient-to-b from-amber-500/10 to-transparent rounded-2xl border border-amber-500/20 inline-block">
              <h3 className="text-white font-semibold text-lg mb-2">Share Your Experience</h3>
              <p className="text-gray-400 text-sm mb-4 max-w-md">
                Were you happy with our service? We'd love to hear from you.
              </p>
              <a
                href={`https://wa.me/${STUDIO_INFO.whatsapp}?text=${encodeURIComponent('I would like to share a review for SRI PALLAVI STUDIO')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-400 text-gray-900 font-semibold rounded-full transition-all"
              >
                <Plus className="w-5 h-5" /> Submit a Review
              </a>
            </div>
          </Reveal>

          <div className="text-center mt-8">
            <Link to="/booking" className="text-amber-400 hover:text-amber-300 text-sm transition-colors">
              Ready to book your session? →
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
