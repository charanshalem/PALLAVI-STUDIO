import { useState } from 'react';
import { Video, Play, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { GalleryItem } from '@/types';
import { GALLERY_CATEGORIES } from '@/types';
import SEO from '@/components/SEO';
import Reveal from '@/components/Reveal';
import { useEffect } from 'react';

export default function Videos() {
  const [videos, setVideos] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('All');
  const [selectedVideo, setSelectedVideo] = useState<GalleryItem | null>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('gallery_items')
        .select('*')
        .eq('media_type', 'video')
        .order('created_at', { ascending: false });
      if (data) setVideos(data);
      setLoading(false);
    })();
  }, []);

  const filtered = activeCategory === 'All'
    ? videos
    : videos.filter((v) => v.category === activeCategory);

  const videoCategories = ['All', ...GALLERY_CATEGORIES.filter((c) => c !== 'All' && videos.some((v) => v.category === c))];

  return (
    <>
      <SEO
        title="Cinematic Films"
        description="Watch cinematic wedding films, pre-wedding videos, and event highlight reels from SRI PALLAVI STUDIO in Pithapuram."
        keywords="wedding videography, cinematic films, wedding video Pithapuram, pre-wedding video, event videography"
      />

      <section className="relative pt-32 pb-16 bg-gradient-to-b from-gray-950 to-gray-900 overflow-hidden">
        <div className="absolute inset-0 opacity-15">
          <img
            src="https://images.pexels.com/photos/5577960/pexels-photo-5577960.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-gray-950/80 to-gray-900/90" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Reveal>
            <p className="text-amber-400 text-sm uppercase tracking-[0.3em] mb-3">Motion Stories</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Cinematic Films</h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Experience our stories through motion — wedding films, highlights, and cinematic videography
            </p>
          </Reveal>
        </div>
      </section>

      {/* Category Filter */}
      {videos.length > 0 && (
        <section className="sticky top-20 z-30 bg-gray-950/95 backdrop-blur-md border-y border-white/5 py-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {videoCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                    activeCategory === cat
                      ? 'bg-amber-500 text-gray-900'
                      : 'bg-white/5 text-gray-300 hover:bg-white/10 hover:text-amber-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="py-16 bg-gray-900 min-h-[50vh]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="flex justify-center py-20">
              <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <Video className="w-16 h-16 text-gray-700 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No videos published yet.</p>
              <p className="text-gray-600 text-sm mt-2">Check back soon for our latest cinematic films!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((video, i) => (
                <Reveal key={video.id} delay={(i % 3) * 80} direction="scale">
                  <div
                    onClick={() => setSelectedVideo(video)}
                    className="group relative overflow-hidden rounded-2xl cursor-pointer aspect-video bg-gray-900"
                  >
                    <img
                      src={video.thumbnail_url || video.media_url}
                      alt={video.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-400" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 rounded-full bg-amber-500/90 group-hover:bg-amber-400 group-hover:scale-110 flex items-center justify-center transition-all duration-300">
                        <Play className="w-7 h-7 text-gray-900 fill-gray-900 ml-1" />
                      </div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <span className="text-amber-400 text-xs uppercase tracking-wider">{video.category}</span>
                      <h3 className="text-white font-semibold text-sm mt-0.5">{video.title}</h3>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Video Player Modal */}
      {selectedVideo && (
        <div
          className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4"
          onClick={() => setSelectedVideo(null)}
        >
          <button
            className="absolute top-6 right-6 text-white/60 hover:text-white transition-colors z-10"
            onClick={() => setSelectedVideo(null)}
          >
            <Play className="w-0 h-0" />
          </button>
          <div className="max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
            <video
              src={selectedVideo.media_url}
              controls
              autoPlay
              className="w-full max-h-[80vh] rounded-lg bg-black"
            />
            <div className="mt-4">
              <span className="text-amber-400 text-xs uppercase tracking-wider">{selectedVideo.category}</span>
              <h3 className="text-white text-xl font-semibold mt-1">{selectedVideo.title}</h3>
              {selectedVideo.description && (
                <p className="text-gray-400 text-sm mt-2">{selectedVideo.description}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
