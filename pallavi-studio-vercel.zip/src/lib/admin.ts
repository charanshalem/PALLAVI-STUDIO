import type { User } from '@supabase/supabase-js';

const adminEmails: Record<string, string> = {
  suresh: 'sripallavist174@gmail.com',
  charan: 'charanshalem@gmail.com',
};
export function resolveAdminEmail(value: string) {
  const normalized = value.trim().toLowerCase();
  return adminEmails[normalized] ?? normalized;
}
export function isStudioAdmin(user: User | null | undefined) {
  return !!user && user.app_metadata?.studio_admin === true &&
    Object.values(adminEmails).includes(user.email?.toLowerCase() ?? '');
}
export function isAllowedAdminEmail(value: string) {
  return Object.values(adminEmails).includes(resolveAdminEmail(value));
}
