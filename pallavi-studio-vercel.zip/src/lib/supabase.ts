import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export const STUDIO_INFO = {
  name: 'SRI PALLAVI STUDIO',
  tagline: 'Every Moment Deserves to Be Timeless',
  owner: 'U. Suresh Babu',
  phone: '9948473174',
  whatsapp: '919948473174',
  email: 'sripallavist174@gmail.com',
  address: 'Near Old Police Station, Pithapuram, Andhra Pradesh',
  mapsUrl: 'https://maps.app.goo.gl/fE1ZCicksvGU85949',
  socials: {
    instagram: '#',
    facebook: '#',
    youtube: '#',
    whatsapp: '#',
  },
};
