import { createContext, useContext, useState, type ReactNode } from 'react';

export type Language = 'en' | 'te';

interface TranslationMap {
  [key: string]: { en: string; te: string };
}

const translations: TranslationMap = {
  nav_home: { en: 'Home', te: 'హోమ్' },
  nav_about: { en: 'About', te: 'మా గురించి' },
  nav_services: { en: 'Services', te: 'సేవలు' },
  nav_gallery: { en: 'Gallery', te: 'గ్యాలరీ' },
  nav_videos: { en: 'Videos', te: 'వీడియోలు' },
  nav_reviews: { en: 'Reviews', te: 'సమీక్షలు' },
  nav_faq: { en: 'FAQ', te: 'ప్రశ్నలు' },
  nav_contact: { en: 'Contact', te: 'సంప్రదించండి' },
  nav_book: { en: 'Book a Shoot', te: 'బుక్ చేయండి' },
  nav_more: { en: 'More', te: 'మరిన్ని' },
  nav_admin: { en: 'Admin', te: 'అడ్మిన్' },
  book_now: { en: 'Book Now', te: 'ఇప్పుడే బుక్ చేయండి' },
  view_gallery: { en: 'View Gallery', te: 'గ్యాలరీ చూడండి' },
  hero_tagline: { en: 'Every Moment Deserves to Be Timeless', te: 'ప్రతి క్షణం శాశ్వతంగా ఉండాలి' },
  hero_sub: {
    en: 'We turn your most precious moments into timeless works of art.',
    te: 'మేము మీ అమూల్యమైన క్షణాలను శాశ్వతమైన కళాఖండాలుగా మారుస్తాము.',
  },
  services_title: { en: 'Our Services', te: 'మా సేవలు' },
  services_sub: { en: 'What We Offer', te: 'మేము అందించేవి' },
  gallery_title: { en: 'Gallery', te: 'గ్యాలరీ' },
  gallery_sub: { en: 'Our Portfolio', te: 'మా పోర్ట్‌ఫోలియో' },
  about_title: { en: 'About Us', te: 'మా గురించి' },
  contact_title: { en: 'Contact Us', te: 'సంప్రదించండి' },
  booking_title: { en: 'Book a Session', te: 'సెషన్ బుక్ చేయండి' },
  reviews_title: { en: 'Customer Reviews', te: 'కస్టమర్ సమీక్షలు' },
  faq_title: { en: 'Frequently Asked Questions', te: 'తరచుగా అడిగే ప్రశ్నలు' },
  videos_title: { en: 'Cinematic Films', te: 'సినిమాటిక్ ఫిల్మ్‌లు' },
  footer_quick_links: { en: 'Quick Links', te: 'త్వరిత లింకులు' },
  footer_services: { en: 'Our Services', te: 'మా సేవలు' },
  footer_contact: { en: 'Get in Touch', te: 'మమ్మల్ని సంప్రదించండి' },
  footer_rights: { en: 'All rights reserved.', te: 'అన్ని హక్కులు అనుకూలం.' },
  cta_ready: { en: 'Ready to Capture Your Story?', te: 'మీ కథను క్యాప్చర్ చేయడానికి సిద్ధం?' },
  cta_contact: { en: 'Contact Us', te: 'మమ్మల్ని సంప్రదించండి' },
  stats_weddings: { en: 'Weddings Shot', te: 'వెడ్డింగ్‌లు' },
  stats_experience: { en: 'Years Experience', te: 'సంవత్సరాల అనుభవం' },
  stats_clients: { en: 'Happy Clients', te: 'సంతృప్తి చెందిన క్లయింట్లు' },
  stats_photos: { en: 'Photos Delivered', te: 'అందించిన ఫోటోలు' },
};

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('studio-lang');
    return saved === 'te' ? 'te' : 'en';
  });

  const handleSetLang = (newLang: Language) => {
    setLang(newLang);
    localStorage.setItem('studio-lang', newLang);
  };

  const t = (key: string): string => {
    const entry = translations[key];
    if (!entry) return key;
    return entry[lang];
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang: handleSetLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
}
