/*
# Storage policies for studio-media bucket

## Security
- Public can READ files from the studio-media bucket (gallery photos/videos visible to visitors)
- Only authenticated users (admin) can UPLOAD, UPDATE, DELETE files
*/

DROP POLICY IF EXISTS "public_read_studio_media" ON storage.objects;
CREATE POLICY "public_read_studio_media"
  ON storage.objects FOR SELECT
  TO anon, authenticated
  USING (bucket_id = 'studio-media');

DROP POLICY IF EXISTS "admin_upload_studio_media" ON storage.objects;
CREATE POLICY "admin_upload_studio_media"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'studio-media');

DROP POLICY IF EXISTS "admin_update_studio_media" ON storage.objects;
CREATE POLICY "admin_update_studio_media"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'studio-media') WITH CHECK (bucket_id = 'studio-media');

DROP POLICY IF EXISTS "admin_delete_studio_media" ON storage.objects;
CREATE POLICY "admin_delete_studio_media"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'studio-media');