/*
# SRI PALLAVI STUDIO - Database Schema

## Overview
Creates the core tables for a photography/videography studio website:
- gallery_items: Photos and videos displayed in the public gallery
- bookings: Customer booking requests for studio services
- messages: Contact form submissions from visitors
- testimonials: Customer reviews shown on the homepage

## Tables

### gallery_items
- id (uuid, PK)
- title (text) - name of the photo/video
- description (text) - optional description
- category (text) - e.g. 'Wedding', 'Portrait', 'Pre-Wedding', 'Events', 'Maternity', 'Kids'
- media_type (text) - 'photo' or 'video'
- media_url (text) - URL to the file in Supabase Storage
- thumbnail_url (text) - optional thumbnail for videos
- is_featured (boolean) - shown on homepage featured section
- sort_order (int) - ordering
- created_at (timestamptz)

### bookings
- id (uuid, PK)
- name, email, phone (text) - customer contact info
- event_type (text) - type of photography service
- event_date (date) - requested date
- message (text) - additional details
- status (text) - 'pending', 'confirmed', 'completed', 'cancelled'
- created_at (timestamptz)

### messages
- id (uuid, PK)
- name, email, phone (text) - visitor contact info
- subject (text) - message subject
- message (text) - the message body
- created_at (timestamptz)

### testimonials
- id (uuid, PK)
- name (text) - customer name
- rating (int) - 1-5 stars
- content (text) - review text
- event_type (text) - what service they used
- created_at (timestamptz)

## Security (RLS)
- gallery_items: Public can read; only authenticated (admin) can insert/update/delete
- testimonials: Public can read; only authenticated (admin) can insert/update/delete
- bookings: Anyone can insert (booking form); only authenticated (admin) can read/update/delete
- messages: Anyone can insert (contact form); only authenticated (admin) can read/delete
- Storage bucket 'studio-media': Public read; only authenticated (admin) can upload
*/

-- Gallery items table
CREATE TABLE IF NOT EXISTS gallery_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  category text NOT NULL DEFAULT 'General',
  media_type text NOT NULL DEFAULT 'photo' CHECK (media_type IN ('photo', 'video')),
  media_url text NOT NULL,
  thumbnail_url text,
  is_featured boolean NOT NULL DEFAULT false,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE gallery_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_gallery" ON gallery_items;
CREATE POLICY "public_read_gallery"
  ON gallery_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_gallery" ON gallery_items;
CREATE POLICY "admin_insert_gallery"
  ON gallery_items FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_gallery" ON gallery_items;
CREATE POLICY "admin_update_gallery"
  ON gallery_items FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_gallery" ON gallery_items;
CREATE POLICY "admin_delete_gallery"
  ON gallery_items FOR DELETE
  TO authenticated USING (true);

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  event_type text NOT NULL,
  event_date date,
  message text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_insert_bookings" ON bookings;
CREATE POLICY "public_insert_bookings"
  ON bookings FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_read_bookings" ON bookings;
CREATE POLICY "admin_read_bookings"
  ON bookings FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_bookings" ON bookings;
CREATE POLICY "admin_update_bookings"
  ON bookings FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_bookings" ON bookings;
CREATE POLICY "admin_delete_bookings"
  ON bookings FOR DELETE
  TO authenticated USING (true);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  subject text,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_insert_messages" ON messages;
CREATE POLICY "public_insert_messages"
  ON messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_read_messages" ON messages;
CREATE POLICY "admin_read_messages"
  ON messages FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_delete_messages" ON messages;
CREATE POLICY "admin_delete_messages"
  ON messages FOR DELETE
  TO authenticated USING (true);

-- Testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  rating int NOT NULL DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  content text NOT NULL,
  event_type text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_testimonials" ON testimonials;
CREATE POLICY "public_read_testimonials"
  ON testimonials FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_testimonials" ON testimonials;
CREATE POLICY "admin_insert_testimonials"
  ON testimonials FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_testimonials" ON testimonials;
CREATE POLICY "admin_update_testimonials"
  ON testimonials FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_testimonials" ON testimonials;
CREATE POLICY "admin_delete_testimonials"
  ON testimonials FOR DELETE
  TO authenticated USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_gallery_category ON gallery_items(category);
CREATE INDEX IF NOT EXISTS idx_gallery_featured ON gallery_items(is_featured);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_created ON bookings(created_at DESC);
